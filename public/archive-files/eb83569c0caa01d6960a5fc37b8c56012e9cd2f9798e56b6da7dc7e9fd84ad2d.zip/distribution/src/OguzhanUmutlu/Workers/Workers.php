<?php

namespace OguzhanUmutlu\Workers;

use invmenu\InvMenuHandler;
use OguzhanUmutlu\Workers\entities\WorkerEntity;
use pocketmine\entity\Entity;
use pocketmine\plugin\PluginBase;

class Workers extends PluginBase {
    /*** @var Workers */
    public static $instance;
    public function onEnable() {
        self::$instance = $this;
        Entity::registerEntity(WorkerEntity::class, true, ["WorkerEntity"]);
        $this->getServer()->getPluginManager()->registerEvents(new EventListener(), $this);
        if(!InvMenuHandler::isRegistered()) InvMenuHandler::register($this);
    }
}
