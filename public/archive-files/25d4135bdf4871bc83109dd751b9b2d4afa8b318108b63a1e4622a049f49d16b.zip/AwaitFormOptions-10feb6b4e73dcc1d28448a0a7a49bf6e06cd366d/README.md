# AwaitFormOptions

## Overview

An option-driven form handler framework built on AwaitForm for `pmmp` plugins.  
Designed to modularize complex user interactions and support clean, reusable, async code.  


## Requirements

- [Cosmoverse/AwaitForm](https://github.com/Cosmoverse/AwaitForm)
- [SOF3/await-generator](https://github.com/SOF3/await-generator)

---

> [!IMPORTANT]
> If you want to use AwaitFormOptions, put this somewhere in your plugin:
> ```php
> if(!AwaitForm::isRegistered()){
>     AwaitForm::register($this); //$this must extend pluginbase
> }
> ```
> ```php
> use cosmicpe\awaitform\AwaitForm;
> ```

---

## ⚠️ Performance Notice
Please be advised that AwaitFormOptions is inherently demanding, both in terms of function call overhead and PHP's garbage collection behavior.  
Due to its layered design and dynamic generator usage, it may not be suitable for performance-critical paths or tight loops   
If maximum performance is your goal, we strongly recommend using AwaitForm directly, rather than through this abstraction layer.    
AwaitFormOptions is designed to simplify complex form workflows and improve developer ergonomics—not to optimize execution speed.   

---

> [!NOTE]
> When using an older version, please refer to the README for that specific version  
> This README also serves as the specification and documentation, and is continuously updated to reflect the latest version. It does not support older versions.   
> To view documentation for older versions, please refer to the corresponding tags.   
>   
> Support Status  
> 1.x series: End of life, There is a significant memory leak  
> 2.x series: End of life,
> 3.x series: Archived and issues are supported  
> 4.x series: In development  


## Why?

Using AwaitForm directly is simple for small forms:  

```php
public function a(PlayerItemUseEvent $event): void {
	$player = $event->getPlayer();
	try {
		await::f2c(function() use ($player) {
			$form = AwaitForm::form("form", [
				FormControl::input("Current HP:", "20", (string) $player->getHealth()),
				FormControl::input("Max HP:", "20", (string) $player->getMaxHealth()),
			]);
			[$current, $max] = yield from $form->request($player);
			$player->setHealth((float) $current);
			$player->setMaxHealth((int) $max);
			$player->sendMessage("HP: {$current}/{$max}");
		});
	} catch (AwaitFormException | FormValidationException) {
		// Cancelled or invalid input
	}
}
```

But when handling multiple related form steps in one screen, things get messy fast.   
**Too many responsibilities are packed into one place.**    
<details align="center">
	<summary>See demo</summary>

https://github.com/user-attachments/assets/5be701db-4a41-4f04-bb49-693a8d40fdb8

</details>


---

## Solution: AwaitFormOptions

Split your form logic into reusable option classes:  

```php
  public function a(PlayerItemUseEvent $event) : void{
      $player = $event->getPlayer();
      Await::f2c(function() use ($player){
          try{
              yield from AwaitFormOptions::sendFormAsync(
                  player: $player,
                  title: "test",
                  options: [
                      new HPFormOptions($player),
                  ]
              );
          }catch(FormValidationException|AwaitFormOptionsParentException){
              // Form failed validation
          }
      });
  }
```

```php
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemUseEvent;
use SOFe\AwaitGenerator\Await;
use DaisukeDaisuke\AwaitFormOptions\AwaitFormOptions;
use DaisukeDaisuke\AwaitFormOptions\exception\AwaitFormOptionsParentException;
use pocketmine\form\FormValidationException;
use cosmicpe\awaitform\AwaitForm;
```

---

## Example Option Class

Each option will yield from `$this->request($form);` and wait for the response. No more losing context!  

> [!TIP]
> `yield from $this->request()` must be called only once per generator.  
> Calling it a second time in the same generator will throw a `AwaitFormOptionsExpectedCrashException`.  
> If you need to re-show a form, return from the current generator and call it again from the parent context.
>
> Additionally, the following exceptions may be thrown from `request()`:
> - `AwaitFormOptionsExpectedCrashException`: When `request()` is called more than once in the same generator.
> - `AwaitFormOptionsExpectedCrashException`: When the provided form/button array is invalid.
> - `AwaitFormOptionsChildException`: If the player rejects the form, input is invalid, or the player logs out.
>
> The try-catch in the child generator may be omitted, but is not recommended.

```php
<?php

declare(strict_types=1);


namespace test\test;

use DaisukeDaisuke\AwaitFormOptions\FormOptions;
use cosmicpe\awaitform\FormControl;
use pocketmine\player\Player;
use DaisukeDaisuke\AwaitFormOptions\exception\AwaitFormOptionsChildException;

class HPFormOptions extends FormOptions{
	public function __construct(private Player $player){
	}

	public function maxHP() : \Generator{
		try{
			$form = [
				FormControl::input("Max HP:", "20", (string) $this->player->getMaxHealth()),
			];
			[$maxHP] = yield from $this->request($form); // awaiting response
			$this->player->setMaxHealth((int) $maxHP);
			$this->player->sendMessage("Max HP: {$maxHP}");
		}catch(AwaitFormOptionsChildException $e){
			var_dump($e->getCode());
		}
	}

	public function currentHP() : \Generator{
		try{
			$form = [
				FormControl::input("Current HP:", "20", (string) $this->player->getHealth()),
			];
			[$currentHP] = yield from $this->request($form); // awaiting response
			$this->player->setHealth((float) $currentHP);
			$this->player->sendMessage("Current HP: {$currentHP}");
		}catch(AwaitFormOptionsChildException $e){
			var_dump($e->getCode());
		}
	}

	public function getOptions() : array{
		return [
			$this->maxHP(),
			$this->currentHP(),
		];
	}

	protected function userDispose() : void{
		unset($this->player);
	}
}
```

![Image](https://github.com/user-attachments/assets/59789bc9-438f-485a-8ca9-625841ce0c66)

---

## Reusability

Yes, option classes are reusable!   
Try passing the same class multiple times:  

```php
public function a(PlayerItemUseEvent $event): void {
    $player = $event->getPlayer();
    Await::f2c(function () use ($player) {
        try {
            yield from AwaitFormOptions::sendFormAsync(
                player: $player,
                title: "test",
                options: [
                    new HPFormOptions($player),
                    new HPFormOptions($player),
                    new HPFormOptions($player),
                    new HPFormOptions($player),
                    new HPFormOptions($player),
                    new HPFormOptions($player),
                ],
            );
        } catch (FormValidationException|AwaitFormOptionsParentException) {
        }
    });
}
```

![Image](https://github.com/user-attachments/assets/29ac3350-7368-4e00-aac8-caadbfabd75a)

Each instance is handled independently.

This means each use should create a separate option object. Do not reuse the same option instance across multiple form or menu executions.

## Standalone

sendForm and sendMenu may also be called standalone. In that case:
- Player rejection and parent-level form failures are swallowed by the standalone wrapper.
- The generator's return value is discarded.
- The functions always return void (null).

Developer errors such as invalid option types, invalid request values, `AwaitFormOptionsExpectedCrashException`, and `AwaitFormOptionsInvalidValueException` are not swallowed by this guarantee.

```php
public function a(PlayerItemUseEvent $event): void {
    $player = $event->getPlayer();
    AwaitFormOptions::sendForm(
        player: $player,
        title: "test",
        options: [
            new HPFormOptions($player),
        ]
    );
}
```

---

## Menu Support

AwaitFormOptions also supports `menu` interactions.   
All menu child generators are started as a race and suspend at `request()` while their elements are collected.  
After the player selects an element, only the selected generator resumes normally. Unselected generators are aborted with `AwaitFormOptionsChildException`.  

> [!TIP]
> When the form is completed, any button generators that were not selected will equally receive a `AwaitFormOptionsChildException` (since 3.0.1)

```php
public function a(PlayerItemUseEvent $event): void {
    $player = $event->getPlayer();
    Await::f2c(function() use ($player): \Generator{
        try{
            yield from AwaitFormOptions::sendMenuAsync(
                player: $player,
                title: "test",
                content: "a",
                buttons: [
                    new NameMenuOptions($player, ["f", "a"]),
                ],
            );
        }catch(FormValidationException|AwaitFormOptionsParentException){

        }
    });
}
```

```php
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemUseEvent;
use SOFe\AwaitGenerator\Await;
use DaisukeDaisuke\AwaitFormOptions\AwaitFormOptions;
use DaisukeDaisuke\AwaitFormOptions\exception\AwaitFormOptionsParentException;
use pocketmine\form\FormValidationException;
use cosmicpe\awaitform\AwaitForm;

```

---

## Example: MenuOptions

Even if multiple buttons share the same label or value, AwaitFormOptions resolves conflicts automatically.  

```php
<?php

declare(strict_types=1);

namespace test\test;

use DaisukeDaisuke\AwaitFormOptions\MenuOptions;
use pocketmine\player\Player;
use cosmicpe\awaitform\MenuElement;
use DaisukeDaisuke\AwaitFormOptions\exception\AwaitFormOptionsChildException;

class NameMenuOptions extends MenuOptions{
	public function __construct(private Player $player, private array $options){
	}

	public function optionsA() : \Generator{
		try{
			$test = [];
			foreach($this->options as $item){
				$test[$item] = MenuElement::button($item);
			}
			$test = yield from $this->request($test);
			$this->player->sendMessage($test.", ".__FUNCTION__);
		}catch(AwaitFormOptionsChildException $exception){
			var_dump("optionA: " . $exception->getCode());
		}
	}

	public function optionsB() : \Generator{
		try{
			$test = yield from $this->request([
				[MenuElement::button("a"), "a"], //Even if you use duplicate keys, Awaitformoption will resolve it
			]);
			$this->player->sendMessage($test.", ".__FUNCTION__);
		}catch(AwaitFormOptionsChildException $exception){
			var_dump("optionB: " . $exception->getCode());
		}
	}

	public function getOptions() : array{
		return [
			$this->optionsB(),
			$this->optionsA(),
		];
	}

	protected function userDispose() : void{
		unset($this->player, $this->options);
	}
}
```

---

## Reusing Menu Options

Just like form options, menu options can be reused as well:  

```php
public function a(PlayerItemUseEvent $event): void {
    $player = $event->getPlayer();
    Await::f2c(function () use ($player) : \Generator{
        try {
            yield from AwaitFormOptions::sendMenuAsync(
                player: $player,
                title: "test",
                content: "a",
                buttons: [
                    new NameMenuOptions($player, ["a", "b"]),
                    new NameMenuOptions($player, ["c", "d"]),
                    new NameMenuOptions($player, ["e", "f"]),
                    new NameMenuOptions($player, ["g", "h"]),
                    new NameMenuOptions($player, ["i", "j"]),
                ]
            );
        } catch (FormValidationException|AwaitFormOptionsParentException) {
        }
    });
}
```

![Image](https://github.com/user-attachments/assets/81872ca7-1e99-4919-9e5e-8c5ee3bf3045)

---

### 🧩 Menu Advanced Usage: Attaching Objects to Buttons
Normally, MenuElement::button("label") returns a `MenuElement` that maps to a string value.
But what if you want to associate a more complex object, like a Player, Entity, or CustomData // with each button?

You can do this easily by passing `[MenuElement::button(...), $value]` into the menu array.

```php
$selected  = yield from $this->request([
    [MenuElement::button("Label A"), $someObject],
    [MenuElement::button("Label B"), "custom-id"],
    [MenuElement::button("Label C"), 123],
]);
```
#### In this format:
- The first element is always a `MenuElement` object.
- The second element is the value that will be returned if the button is selected.
- The returned result is mapped correctly even for duplicate labels or repeated values.
- You can use any scalar or object, including players, entities, and custom classes.

### Example

```php
public function onUse(PlayerItemUseEvent $event): void{
    $player = $event->getPlayer();
    if(!$player->isSneaking()){
        return;
    }
    Await::f2c(function() use ($player) {
        try {
            $entities = [];
            $world = $player->getWorld();
            foreach($world->getEntities() as $entity){
                if(!$entity instanceof Living){
                    continue;
                }
                $entities[] = $entity;
            }

            yield from AwaitFormOptions::sendMenuAsync(
                player: $player,
                title: "Food Assistance",
                content: "Please select an option",
                buttons: [
                    new EntityNameMenuOptions($player, $entities),
                ]
            );
        } catch (FormValidationException|AwaitFormOptionsParentException) {
            // The form was cancelled or failed
        }
    });
}
```

### EntityNameMenuOptions.php

```php
<?php

declare(strict_types=1);


namespace test\test;

use DaisukeDaisuke\AwaitFormOptions\MenuOptions;
use pocketmine\player\Player;
use cosmicpe\awaitform\MenuElement;
use pocketmine\entity\Entity;
use DaisukeDaisuke\AwaitFormOptions\exception\AwaitFormOptionsChildException;

class EntityNameMenuOptions extends MenuOptions{
	public function __construct(private Player $player, private array $entities){
	}

	public function chooseEntity() : \Generator{
		try{
			$buttons = [];

			foreach($this->entities as $entity){
				// Display name, attach Entity instance
				$buttons[] = [MenuElement::button($entity->getName()), $entity];
			}

			/** @var Entity $selected */
			$selected = yield from $this->request($buttons);

			$this->player->sendMessage("You chose: " . $selected->getName());
			return $selected;
		}catch(AwaitFormOptionsChildException){
			// Closed
		}
	}

	public function getOptions() : array{
		return [$this->chooseEntity()];
	}

	protected function userDispose() : void{
		unset($this->player, $this->entities);
	}
}
```

---

## Generator Return Values
Each generator that you define in your FormOptions or MenuOptions class can return a value using the return statement.

For forms, all participating generator return values are collected into an array and returned from `AwaitFormOptions::sendFormAsync()`.
For menus, only the selected generator's return value is returned from `AwaitFormOptions::sendMenuAsync()`; aborted generators do not contribute return values.

This allows you to treat each form step as a small function that produces a result, just like any other callable.

## Menu Example
Here, the selected button id is returned directly from the generator:

> [!NOTE]
> Please Note that if the form fails, an AwaitFormOptionsParentException is thrown and you never get the return value


```php
public function onUse(PlayerItemUseEvent $event): void{
    $player = $event->getPlayer();
    if(!$player->isSneaking()){
        return;
    }
    Await::f2c(function() use ($player) {
        try {
            $selected = yield from AwaitFormOptions::sendMenuAsync(
                player: $player,
                title: "Food Assistance",
                content: "Please select an option",
                buttons: [
                    new SimpleButton("test1", 0),
                    new SimpleButton("test2", 2),
                ]
            );
            var_dump($selected);
        } catch (FormValidationException|AwaitFormOptionsParentException) {
            // The form was cancelled or failed
        }
    });
}
```

### SimpleButton

```php
<?php

declare(strict_types=1);

namespace test\test;

use DaisukeDaisuke\AwaitFormOptions\MenuOptions;
use cosmicpe\awaitform\MenuElement;
use cosmicpe\awaitform\AwaitFormException;
use DaisukeDaisuke\AwaitFormOptions\exception\AwaitFormOptionsChildException;

class SimpleButton extends MenuOptions{
	public function __construct(private string $name, private int $id){
	}

	public function choose(int $offset) : \Generator{
		try{
			yield from $this->request(
				[MenuElement::button($this->name), 0]
			);
			return $this->id + $offset;
		}catch(AwaitFormOptionsChildException){
			// Closed
		}
	}

	public function getOptions() : array{
		return [
			$this->choose(0),
			$this->choose(1),
		];
	}
	protected function userDispose() : void{
		unset($this->name, $this->id);
	}
}
```

### result
Any of the following
```
int(0)
int(1)
int(2)
int(3)
NULL
```


---

## Form Example
Forms can retrieve the return value of a generator in the same way, note that in this case it maps to the keys of the option array.

> [!TIP]
> In `sendFormAsync()`, the return value preserves:  
>  
> - The keys from the top-level `options` array, and  
> - The keys from each `FormOptions::getOptions()` result.  
>  
> This allows both levels of return values to be mapped clearly.    
> For example:  
>  
> ```php
> public function getOptions(): array {
>     return ["test" => $this->confirmOnce()];
> }
> ```
>  
> And if you pass `["output" => new ConfirmInputForm()]` into `sendFormAsync()`,  
> and the generator returned `"yes"` from the `"test"` key,  
> the result will be:  
>  
> ```php
> [
>     "output" => [
>         "test" => "yes" // (← this is the value returned from the generator)
>     ]
> ]
> ```
>
>  
> However, in `sendMenuAsync()`, only the return value of the **selected generator** is returned.  
> You will either get:  
>  
> - The return value from the selected `MenuOptions` generator
> - If the form fails, an exception will be thrown and no value will be received
>  
> Thus:  
>
> ✅ `getOptions()` keys → respected in `sendFormAsync()`   
> ❌ `getOptions()` keys → ignored in `sendMenuAsync()` (since only one is returned)  
  

```php
public function onUse(PlayerItemUseEvent $event): void{
    $player = $event->getPlayer();
    if(!$player->isSneaking()){
        return;
    }
    Await::f2c(function() use ($player) {
        try {
            $selected = yield from AwaitFormOptions::sendFormAsync(
                player: $player,
                title: "test",
                options: [
                    "input1" => new SimpleInput("test1", "test", "test", 0),
                    "input2" => new SimpleInput("test2", "test2", "test2", 0),
                ]
            );
            var_dump($selected);
        } catch (FormValidationException|AwaitFormOptionsParentException) {
            // The form was cancelled or failed
        }
    });
}
```

### SimpleInput.php

```php
<?php

declare(strict_types=1);

namespace test\test;

use DaisukeDaisuke\AwaitFormOptions\FormOptions;
use cosmicpe\awaitform\FormControl;

class SimpleInput extends FormOptions{
	public function __construct(private string $text, private string $default, private string $placeholder, private int $id){
	}

	/**
	 * @throws AwaitFormOptionsChildException
	 */
	public function input(int $offset) : \Generator{
		$output = yield from $this->request([FormControl::input($this->text, $this->default, $this->placeholder), $this->id + $offset]);
		return $output[array_key_first($output)];
	}

	/**
	 * @throws AwaitFormOptionsChildException
	 */
	public function getOptions() : array{
		return [
			$this->input(0),
			$this->input(1),
		];
	}
	protected function userDispose() : void{
		unset($this->text, $this->default, $this->placeholder, $this->id);
	}
}

```

### result

```
array(2) {
  ["input1"]=>
  array(2) {
    [0]=>
    string(4) "test"
    [1]=>
    string(4) "test"
  }
  ["input2"]=>
  array(2) {
    [0]=>
    string(5) "test2"
    [1]=>
    string(5) "test2"
  }
}
```

---

# Example

### 🐲 MobKillerOptions (Entity Interaction via Menu)
AwaitFormOptions can be used for more than just player configuration, it also allows you to handle dynamic entities such as mobs or NPCs using menu interactions.
Here is a concrete example that lets a player select entities in their current world and kill them via a menu.

![Image](https://github.com/user-attachments/assets/a7bc338d-2851-450a-8827-5bb3392d5137)

```php
public function onUse(PlayerItemUseEvent $event): void{
    $player = $event->getPlayer();
    $world = $player->getWorld();

    if(!$player->isSneaking()){
        return;
    }

    $forms = [];
    foreach($world->getEntities() as $entity){
        if($entity === $player || !$entity instanceof Living){
            continue;
        }
        $forms[] = new MobKillerForm($entity);
    }

    Await::f2c(function() use ($player, $forms) : \Generator{
        try{
            yield from AwaitFormOptions::sendMenuAsync(
                player: $player,
                title: "Mob Terminator",
                content: "Choose a mob to eliminate:",
                buttons: $forms
            );
        }catch(AwaitFormOptionsParentException $exception){

        }
    });
}
```

### 🧪 Option Class Example: MobKillerForm

```php
<?php

declare(strict_types=1);


namespace test\test;

use DaisukeDaisuke\AwaitFormOptions\MenuOptions;
use pocketmine\entity\Entity;
use cosmicpe\awaitform\MenuElement;
use DaisukeDaisuke\AwaitFormOptions\exception\AwaitFormOptionsChildException;

class MobKillerForm extends MenuOptions{

	public function __construct(private Entity $entity){
	}

	/**
	 * @throws AwaitFormOptionsChildException
	 */
	public function KillerForm() : \Generator{
		yield from $this->request([
			[MenuElement::button($this->entity->getName() . " (" . $this->entity->getId() . ")"), "a"],
		]);
		//In this coroutine, all options are executed and competed against; only the winning option is reached, while the others are interrupted by an `AwaitFormOptionsChildException` (ERR_COROUTINE_ABORTED), and their return values are ignored.
		//Conversely, by catching `AwaitFormOptionsChildException` (ERR_COROUTINE_ABORTED), it is possible to perform specific handling for the option that was not selected (v3.0.0 and later).
		//If the form is canceled (e.g., logged out, rejected by the player, the player already has a GUI and opening it fails), an AwaitFormOptionsChildException with a code, as defined in AwaitFormException, will be thrown.
		$this->entity->kill();
	}

	/**
	 * @throws AwaitFormOptionsChildException
	 */
	public function getOptions() : array{
		return [
			$this->KillerForm(),
		];
	}

	protected function userDispose() : void{
		unset($this->entity);
	}
}
```

---

## Non-Cancellable Form (Forced Confirmation)
Sometimes, you want to prevent players from skipping or cancelling a form unless they acknowledge a specific phrase or condition // such as typing "yes".
With AwaitFormOptions, this can be done cleanly by combining input validation and throwExceptionInCaller: true.

### Usage

![Image](https://github.com/user-attachments/assets/8e735c4f-c674-4e4e-8cde-79cbb8ab378f)

```php
public function onUse(PlayerItemUseEvent $event) : void{
    $player = $event->getPlayer();
    if(!$player->isSneaking()){
        return;
    }
    Await::f2c(function() use ($player){
        while(true){
            try{
                $result = yield from AwaitFormOptions::sendFormAsync(
                    player: $player,
                    title: "Confirmation",
                    options: ["output" => new ConfirmInputForm()]
                );
                //generator returns
                $typed = $result["output"][0];
                if(strtolower(trim($typed)) === "yes"){
                    $player->sendToastNotification("Confirmed", "Thanks for typing!");
                    break;
                }

            }catch(FormValidationException|AwaitFormOptionsParentException $exception){
                if($exception instanceof FormValidationException){
                    return;
                }
                if($exception->getCode() !== AwaitFormException::ERR_PLAYER_REJECTED){
                    break;
                }
            }
            $player->sendToastNotification("You must type 'yes'.", "please Type 'Yes'");
        }
    });
}
```

### 🧪 Option Class: ConfirmInputForm

```php
<?php

declare(strict_types=1);

namespace test\test;

use DaisukeDaisuke\AwaitFormOptions\FormOptions;
use cosmicpe\awaitform\FormControl;
use DaisukeDaisuke\AwaitFormOptions\exception\AwaitFormOptionsChildException;

class ConfirmInputForm extends FormOptions{
	/**
	 * @throws AwaitFormOptionsChildException
	 */
	public function confirmOnce(): \Generator {
		[$input] = yield from $this->request([
			FormControl::input("Type 'yes' to confirm", "yes", ""),
		]);
		return $input;
	}

	/**
	 * @throws AwaitFormOptionsChildException
	 */
	public function getOptions(): array {
		return [$this->confirmOnce()];
	}

	protected function userDispose() : void{

	}
}
```

---

## 🍖 HP-Dependent Form Options (Dynamic Option Filtering)
You can conditionally include different form options by selecting which yield generators are returned from getOptions(), this is a key strength of AwaitFormOptions over flat form construction.

![Image](https://github.com/user-attachments/assets/d3d51ed1-4b67-4530-8b9b-f95eba980cdb)

### HpBasedFoodOptions.php

```php
<?php

declare(strict_types=1);


namespace test\test;


use pocketmine\player\Player;
use pocketmine\item\VanillaItems;
use cosmicpe\awaitform\MenuElement;
use DaisukeDaisuke\AwaitFormOptions\MenuOptions;
use DaisukeDaisuke\AwaitFormOptions\exception\AwaitFormOptionsChildException;

class HpBasedFoodOptions extends MenuOptions{

	public function __construct(private Player $player){
	}

	/**
	 * @throws AwaitFormOptionsChildException
	 */
	public function giveRawFish() : \Generator{
		yield from $this->request([
			MenuElement::button("§2You are full of strength! Enjoy this raw fish.§r"),
		]);
		$this->player->getInventory()->addItem(VanillaItems::RAW_FISH()->setCount(1));
		$this->player->sendToastNotification("Food Given", "Raw Fish");
	}

	/**
	 * @throws AwaitFormOptionsChildException
	 */
	public function giveCookedFish() : \Generator{
		yield from $this->request([
			MenuElement::button("§6You're moderately hurt. Take this cooked fish.§r"),
		]);
		$this->player->getInventory()->addItem(VanillaItems::COOKED_FISH()->setCount(1));
		$this->player->sendToastNotification("Food Given", "Cooked Fish");
	}

	/**
	 * @throws AwaitFormOptionsChildException
	 */
	public function giveSteak() : \Generator{
		yield from $this->request([
			MenuElement::button("§4You're starving! Here's a juicy steak.§r"),
		]);
		$this->player->getInventory()->addItem(VanillaItems::STEAK()->setCount(1));
		$this->player->sendToastNotification("Food Given", "Steak");
	}

	/**
	 * @throws AwaitFormOptionsChildException
	 */
	public function getOptions() : array{
		$hp = $this->player->getHealth();

		$result = [];
		if($hp <= 20){
			$result[] = $this->giveRawFish();
		}
		if($hp <= 10){
			$result[] = $this->giveCookedFish();
		}
		if($hp <= 5){
			$result[] = $this->giveSteak();
		}
		return $result;
	}

	protected function userDispose() : void{
		unset($this->player);
	}
}
```

### Usage

```php
	public function onUse(PlayerItemUseEvent $event): void{
		$player = $event->getPlayer();
		if(!$player->isSneaking()){
			return;
		}
		Await::f2c(function() use ($player) {
			try {
				yield from AwaitFormOptions::sendMenuAsync(
					player: $player,
					title: "Food Assistance",
					content: "Please select an option",
					buttons: [
						new HpBasedFoodOptions($player),
					]
				);
			} catch (FormValidationException|AwaitFormOptionsParentException) {
				// The form was cancelled or failed
			}
		});
	}
```

### Form Available elements

```php
FormControl::divider() // Adds a horizontal divider to visually separate form sections.
FormControl::dropdown(string $label, array $options, ?string $default = null) // Select from a list of options, returns the selected value.
FormControl::dropdownIndex(string $label, array $options, int $default = 0) // Select from a list of options, returns the selected index.
FormControl::dropdownMap(string $label, array $options, array $mapping, mixed $default = null) // Select from a list of options, returns a mapped value.
FormControl::header(string $label) // Adds a bold header text to highlight sections.
FormControl::input(string $label, string $placeholder = "", string $default = "") // Text input field. Returns user input as a string.
FormControl::label(string $label) // Static text label, for descriptions or instructions.
FormControl::slider(string $label, float $min, float $max, float $step = 0.0, float $default = 0.0) // A numeric slider. Returns a float value.
FormControl::stepSlider(string $label, array $steps, ?string $default = null) // A discrete slider with string options. Returns a selected step.
FormControl::toggle(string $label, bool $default = false) // A boolean toggle (checkbox). Returns true/false.
```

### Menu Available elements
```php
MenuElement::button(string $text) // One user selectable button with text
MenuElement::buttonWithImagePath(string $text) // Please specify the path within the resource pack
MenuElement::buttonWithImageUrl(string $text) // This is obtained by the client, but there is a bug.
MenuElement::divider(string $text) // Adds a horizontal divider to visually separate form sections.
MenuElement::header(string $text) //  Adds a bold header text to highlight sections.
MenuElement::label(string $text) //  Static text label, for descriptions or instructions.
```

## ⚠️ Notes on `getOptions()`

The `getOptions()` method must return an array of child `\Generator` instances. It may also return one level of nested `FormOptions` or `MenuOptions` of the same kind. Each generator represents a step in the asynchronous form process. Misuse of this method may result in exceptions or undefined behavior.

---

### ❌ Mistake 1: Returning non-generators

```php
// ❌ This will throw an exception because the array is not a list of generators or same-kind nested options
public function getOptions(): array {
    return ["not a generator"];
}
```

✅ **Correct:** Ensure each item in the array is a generator using `yield`, or a same-kind nested option object.  

```php
public function getOptions(): array {
    return [
        $this->confirmSomething()
    ];
}
```

---

### ❌ Mistake 2: Using `yield from` inside `getOptions()`  

```php
// ❌ Syntax error: you cannot use `yield` or `yield from` in a non-generator method
public function getOptions(): array {
    $value = yield from $this->step(); // Invalid
    return [];
}
```
 
✅ **Correct:** Move the logic into a generator method and return it from `getOptions()`

```php
public function flow(): \Generator {
    $value = yield from $this->step();
    // ...
}

public function getOptions(): array {
    return [$this->flow()];
}
```

---

### ❌ Mistake 3: Returning objects

```php
// ❌ Unrelated objects are not supported
public function getOptions(): array {
    return [
        new \stdClass($this->player),
    ];
}
```

✅ **Correct:** Return a generator or one level of nested option object of the same kind. Form options and menu options cannot be mixed, and deeper nesting is rejected.

---

### ❌ Mistake 4: Calling request multiple times in a child generator
You cannot resubmit the form from the child generator  

```php
// ❌ Calling it multiple times will result in an error, so you must call it again from the parent generator.
public function flow(): \Generator {
    $value1 = yield from $this->request(...);
    $value2 = yield from $this->request(...);
    $value3 = yield from $this->request(...);
    $value4 = yield from $this->request(...);
    // ...
}

public function getOptions(): array {
    return [$this->flow()];
}
```

✅ **Correct:** Only the parent generator has the right to resubmit the menu.

---

### ✅ Returning an empty array when no steps are needed  

```php
public function getOptions(): array {
    return []; // No form step
}
```

---

## ⚠️ What to be aware of if you don't call request first in your generator

If your generator does **not** start with `yield from $this->request(...)`, you **must** call `$this->schedule();` to inform the AwaitFormOptions system that a `request()` is coming later  
If you forget this, the system may either **ignore the `request()` entirely**, or worse, **cause a memory leak** due to improper bridge state retention　　

#### ❌ Incorrect Example

```php
public function flow(): \Generator {
    if ($someCondition) {
        yield from $this->stepA(); // Not a request, no schedule
    }
    yield from $this->request([...]); // This may be ignored or cause a leak
}
```

✅ Correct: If you think you might call await several times in advance, use `$this->schedule();` beforehand

```php
public function flow(): \Generator {
    $this->schedule(); // Declare intention to request later
    if ($input === "A") {
        yield from $this->stepA();
    }
    $input = yield from $this->request([...]);
}
```


## ❓ How can I preserve the state of a form?
Currently, this is a known limitation and an ongoing area of exploration. In the core-sod architecture, all input states are managed and validated through a flat, object-oriented structure. Each form field's value is stored in a persistent object that represents the current session.  
🧩 In principle, such an object should be sufficient to retain or finalize form state across multiple steps or deferred interactions.  
However, please note that we do not plan to fully solve this problem in the near future. The current approach is intended to be minimal, avoiding deep form serialization or complex state tracking, in order to keep the system maintainable and predictable.  
While improvements may be considered in the future, this area is not a development priority at the moment.  
  

## ❓How about PMServerUI?
PMServerUI (https://github.com/DavyCraft648/PMServerUI) is a great library for beginners who want to create simple and clean UI menus with minimal effort. Its straightforward API makes it easy to build forms quickly.  
However, AwaitFormOptions provides a more powerful and flexible system that supports deeply nested options, persistent context between form steps, and asynchronous flow control.  
While it is technically possible to recreate something like PMServerUI using AwaitFormOptions, the reverse is not true. PMServerUI cannot handle advanced patterns such as dynamic generator-based form logic, branching flows, or contextual state within multi-step UIs.  

## ❓Why isn't `Dialog` supported by `AwaitFormOptions`?
Since `dialog` is a very simple operation that does not require extending the API beyond `AwaitForm::dialog`, it was decided not to support it in `AwaitFormOptions`  
Therefore, you must use `AwaitForm::dialog` directly without relying on the `AwaitFormOptions` ecosystem, and must manually handle `$form->request()` and `AwaitFormException`  


```php
Await::f2c(function() : \Generator{
	try{
		$menu = AwaitForm::dialog(
			title: "aaaa",
			content: "bbbb",
		);;
		$bool = yield from $menu->request($sender);
	}catch(AwaitFormException|FormValidationException){
		return;
	}
});
```

---

## Handling child generator exceptions with `@throws AwaitFormOptionsChildException`

This section explains how exceptions thrown from **child generators** are handled in AwaitFormOptions, how `@throws AwaitFormOptionsChildException` interacts with phpstan, and how branching by error code works in practice.

The goal is to make exception flow explicit, predictable, and statically analyzable, without hiding important runtime behavior.

---

## Basic idea 💡

* Child generator methods (those using `yield from $this->request(...)`) may fail for several reasons:

  * the player closed the form
  * the player quit the server
  * validation failed
  * the coroutine was aborted internally

* These failures are surfaced as exceptions derived from the AwaitFormOptions exception hierarchy:

  * `AwaitFormOptionsChildException` (child-side)

    * `ERR_COROUTINE_ABORTED = 300001`
  * `AwaitFormOptionsParentException` (parent-side)

    * `ERR_VERIFICATION_FAILED = 200001`
  * `AwaitFormException` (base AwaitForm errors)

    * `ERR_PLAYER_REJECTED = 100002`
    * `ERR_PLAYER_QUIT = 100003`
    * `ERR_VALIDATION_FAILED = 100001`

* By documenting child generators with `@throws AwaitFormOptionsChildException`, phpstan understands that:

  * This coroutine does not catch exceptions

This keeps both humans and static analysis tools aligned 👍

---

## Annotating a child generator 🧩

Any generator that can throw a child exception should declare it explicitly:
If an `AwaitFormOptionsChildException` is thrown from a child generator, `AwaitFormOptions` will silently catch it
This was originally a bug in v3.0.0, but because it was useful, it was accepted as part of the specification
Remember to add `throws` to your generator functions and `getOptions`, as phpstan will complain otherwise!

```php
/**
 * @throws \DaisukeDaisuke\AwaitFormOptions\exception\AwaitFormOptionsChildException
 */
public function confirmOnce(): \Generator {
    [$input] = yield from $this->request([
        FormControl::input("Type 'yes' to confirm", "yes", ""),
    ]);

    return $input;
}

/**
 * @throws \DaisukeDaisuke\AwaitFormOptions\exception\AwaitFormOptionsChildException
 */
public function getOptions() : array{
    return [
        $this->KillerForm(),
    ];
}
```

Why this matters:

* phpstan treats the exception as part of the method contract
* the control flow becomes explicit and reviewable

---

## Catching and branching by error code 🎯

`AwaitFormOptionsChildException` carries a numeric error code.
This allows fine-grained branching without relying on exception type explosions.

### Example: handling child exceptions locally

```php
/**
 * @throws \DaisukeDaisuke\AwaitFormOptions\exception\AwaitFormOptionsChildException
 */
public function editName(): \Generator {
    try {
        [$name] = yield from $this->request([
            FormControl::input("Enter new name", "player", ""),
        ]);

        $this->player->setName($name);
        return $name;

    } catch (\DaisukeDaisuke\AwaitFormOptions\exception\AwaitFormOptionsChildException $e) {
        switch ($e->getCode()) {
            case AwaitFormOptionsChildException::ERR_COROUTINE_ABORTED:
                // internal abort (race, shutdown, etc.)
                $this->player->sendMessage("Operation aborted by server");
                break;

            case \cosmicpe\awaitform\AwaitFormException::ERR_PLAYER_REJECTED:
                // form closed
                $this->player->sendMessage("Form was closed");
                break;

            case \cosmicpe\awaitform\AwaitFormException::ERR_PLAYER_QUIT:
                // player left the server
                // usually nothing to do here
                break;

            default:
                //If you throw an AwaitFormOptionsChildException it will be silently ignored by the system, so if you want to crash the server use any other exception
                throw RuntimeException("Unexpected error");
        }

        return null;
    }
}
```

Notes:

* Even though you catch `AwaitFormOptionsChildException`,
  the error code may originate from `AwaitFormException`.
* Child generators do not catch `FormValidationException` from `$this->request()`.
  AwaitForm validation failures are converted on the parent side to `AwaitFormOptionsParentException::ERR_VERIFICATION_FAILED`.
* This design allows a **single catch block** with **precise branching** ✨

---


If an exception is thrown, the coroutine flow is immediately aborted.
Child-level exceptions are thrown from `request()` and are always swallowed when they are instances of `AwaitFormOptionsChildException`.
Parent-level exceptions are thrown from `sendFormAsync()` or `sendMenuAsync()` and must be handled by the parent coroutine.
Once an exception occurs, return values and child generator results are invalid.


## Parent Generator Exception Handling

```php
Await::f2c(function() use ($player): \Generator {
    try {
        yield from AwaitFormOptions::sendFormAsync(
            player: $player,
            title: "Confirm action",
            options: [
                new ConfirmInputForm($player),
            ],
        );

    } catch (AwaitFormOptionsParentException|FormValidationException $e) {
        if ($e->getCode() === AwaitFormOptionsParentException::ERR_VERIFICATION_FAILED) {
            $player->sendMessage("Verification failed");
            return;
        }

        // other parent-level failures
        var_dump($e->getMessage());
    }
});
```

Handling of the parent generator's `AwaitFormOptionsParentException` and `FormValidationException` is a **must**
Failure to do so will cause the server to crash with a very long error message when an exception occurs

---

## phpstan behavior 🧠

* When `@throws AwaitFormOptionsChildException` is present:

  * phpstan requires callers to acknowledge it
  * missing `try/catch` becomes a static error

* If the exception is intentionally allowed to propagate freely:

  * it can be configured as *unchecked* in phpstan
  * this suppresses enforcement but also removes safety guarantees ⚠️

In general, explicit `@throws` + explicit handling is recommended.

---

## Summary ✅

* Use `@throws AwaitFormOptionsChildException` on child generators
* Catch child exceptions where user feedback or recovery is meaningful
* Branch by `getCode()` instead of multiplying exception classes
* Rethrow when the decision belongs to the parent
* Avoid silently swallowing exceptions, both at runtime and in phpstan

This approach keeps coroutine-based form handling **predictable**, **type-aware**, and **maintainable** over time 🚀

---

# GPT Notes / Common Misinterpretations

The following points are frequently misunderstood when reading this library for the first time, especially by LLMs or developers expecting a traditional form abstraction.

## `request()` does not send a form

`request()` is not equivalent to `AwaitForm::request()`.

Calling `request()` only registers form elements or menu elements into an internal bridge. The actual form is assembled and sent later by the parent coroutine after all requests have been collected.

In other words, child generators do not interact with the player directly. They only describe what should be added to the final form.

---

## `request()` is intentionally limited to one call per child generator

This is not an arbitrary limitation.

The bridge architecture assumes a one-request-per-child lifecycle. Supporting multiple requests inside the same child generator would require tracking coroutine-local request identities across multiple suspension points.

Consider:

```php
yield from $this->request(...);
yield from $this->request(...);
```

while another child generator is currently awaiting a third request.

The parent coroutine would no longer be able to reliably determine which pending response belongs to which logical request chain.

Because of this ambiguity, multiple requests per child generator are intentionally unsupported.

---

## `schedule()` is not a delayed execution system

The name may suggest task scheduling or deferred execution.

It does neither.

`schedule()` creates a reservation that prevents the parent coroutine from collecting requests prematurely. It acts as a synchronization barrier, ensuring that future requests are accounted for before form construction begins.

A more accurate mental model is "reservation" or "barrier registration", not "scheduled execution".

---

## `finalize()` is a synchronization primitive, not a cleanup hook

The name may suggest resource disposal or shutdown logic.

In reality, `finalize()` suspends the child coroutine until the bridge explicitly releases all registered finalizers.

Conceptually it behaves closer to:

- barrier synchronization
- latch waiting
- join semantics

than to traditional finalization logic.

---

## Menu execution is eager, not lazy

For menu options, child generators begin execution before the player makes a selection.

The system does not wait until a button is clicked before starting its corresponding coroutine.

All menu option generators are started immediately. When one option wins, the remaining generators are aborted.

This behavior is closer to a race than to a callback-based menu system.

---

## Missing `schedule()` calls cannot be reliably detected

A common assumption is that the library should automatically detect forgotten `schedule()` calls.

In practice, this is impossible to determine reliably.

From the bridge's perspective, an unresolved reservation and a generator that intentionally never reaches a request are indistinguishable.

Any automatic detection would inevitably produce false positives.

---

## `userDispose()` is part of the lifecycle

It may be tempting to assume that PHP's garbage collector or a WeakMap-based design would make `userDispose()` unnecessary.

This is not the case.

Child generators may remain suspended while awaiting user interaction, requiring strong references to remain valid throughout their lifetime.

`userDispose()` exists to provide deterministic cleanup when the bridge lifecycle ends.

---

## Nested options are intentionally limited

Nested `FormOptions` or `MenuOptions` are supported only one level deep.

The library expands:

```text
FormOptions
 └─ FormOptions
     └─ Generator
```

but does not recursively expand arbitrary nesting depths.

Deep recursive expansion is intentionally rejected to keep ownership and lifecycle management predictable.

---

## This library is primarily a coroutine bridge

It may appear to be a form utility library, but forms are only one application of the underlying design.

The core responsibility of the system is coordinating bidirectional communication between child generators and a parent coroutine.

Understanding the library as a coroutine bridge rather than a form framework generally leads to a much more accurate mental model of how it behaves internally.

## Element ordering follows coroutine execution order

Menu buttons and form elements are ordered according to the order in which child generators register their requests.

The library does not perform explicit sorting or priority-based reordering. Elements are collected in the order that `request()` calls reach the bridge.

In practice, this means ordering is usually determined by:

- the order of parent options
- the order of nested child options
- the execution flow inside each generator

Because child generators are executed concurrently, introducing additional suspension points before `request()` may change the final ordering.

For example:

```php
yield from someAsyncOperation();
yield from $this->request(...);
```

may register its elements later than another generator that reaches `request()` immediately.

This behavior is intentional. The library treats coroutine execution order as the source of truth, making the resulting ordering deterministic and naturally derived from the structure and execution flow of the option tree rather than from an additional sorting layer.

As a rule of thumb, if no extra suspension points are introduced before `request()`, the visible order will generally match the order in which parent options and nested child options are defined.


## What "Bridge" actually means

The term "bridge" in this library has a very specific meaning.

It is not:

- an event bus
- a task scheduler
- a message queue
- a form manager
- a coroutine executor

Instead, the bridge exists solely to connect child generators and the parent coroutine.

Child generators cannot directly communicate with the final form instance. Likewise, the parent coroutine cannot directly access the internal state of child generators.

The bridge provides a controlled communication channel between both sides.

```text
Child Generator
       │
       ▼
request()
       │
       ▼
RequestResponseBridge
       │
       ▼
Parent Coroutine
       │
       ▼
AwaitForm
       │
       ▼
Player Response
       │
       ▼
RequestResponseBridge
       │
       ▼
solve() / reject()
       │
       ▼
Child Generator
```

The bridge therefore has two responsibilities:

1. Collect requests produced by child generators.
2. Deliver responses or exceptions back to the originating child generators.

The bridge does not generate forms, render UI, manage player sessions, or schedule execution. It only coordinates data flow between coroutines.

Understanding this distinction is important because many implementation details become much easier to reason about:

- `request()` registers a future response.
- `solve()` completes a pending request.
- `reject()` aborts a pending request.
- `schedule()` reserves a future request.
- `finalize()` waits for bridge completion.

Most of the library's behavior is a consequence of this communication model.


## Form and Menu are fundamentally different execution models

Although both APIs expose child generators and `request()`, Form and Menu execution models are intentionally different and should not be treated as interchangeable.

### Form

Forms are composed of multiple interactive controls such as:

- input fields
- toggles
- sliders
- dropdowns

Every child generator contributes part of a single form.

After the form is submitted:

- all child generators are expected to complete successfully
- each child generator receives the value associated with its request

If the player closes the form or otherwise fails to provide a response:

- every waiting child generator receives `AwaitFormOptionsChildException`

A Form therefore behaves as a collective operation where all participating child generators are expected to receive a result.

---

### Menu

Menus are composed of selectable entries.

Each child generator represents a possible choice.

Unlike Forms, all menu generators begin execution immediately and continue running until they reach their first `request()`.

Once all requests have been collected and the menu is shown:

- selecting an entry produces exactly one winner
- the winning generator resumes from `request()` and continues execution
- all other generators receive `AwaitFormOptionsChildException`

A Menu therefore behaves as a race between child generators rather than a collective operation.

Only one generator is expected to complete normally.

---

### Mental model

Form:

```text
Generator A -> request()
Generator B -> request()
Generator C -> request()

Player submits form

Generator A receives value
Generator B receives value
Generator C receives value
```

Menu:

```text
Generator A -> request()
Generator B -> request()
Generator C -> request()

Player selects B

Generator B resumes
Generator A aborted
Generator C aborted
```

Many implementation details become easier to understand once Forms are viewed as a shared result model and Menus are viewed as a winner-takes-all race model.


## `request()` should be considered a terminal suspension point

After a child generator reaches `request()`, introducing unrelated asynchronous suspension points is unsupported.

Example:

```php
yield from $this->request(...);
yield from someAsyncOperation();
```

The second `yield from` is undefined behavior.

Depending on execution flow, this may lead to:

- unexpected behavior
- orphaned coroutines
- resource leaks
- unresolved bridge state

Returning a value after `request()` is supported.
`yield from $this->finalize(...)` is also supported as the built-in post-request synchronization point.

Creating new unrelated asynchronous suspension points after `request()` is not.  
These operations should be delegated to the parent generator, with the child generator merely returning the values.  

## Architectural note

The execution model is not driven by independent objects.

Instead, AwaitFormOptions creates an internal coroutine coordination system composed of:

- an AwaitFormOptions execution coroutine
- a RequestResponseBridge
- child generators
- an AwaitForm driver
- A suspended coroutine provided by AwaitGenerator

User code typically interacts only with `sendFormAsync()` or `sendMenuAsync()`.

```text
User coroutine
        │
        ▼
sendFormAsync() / sendMenuAsync()
        │
        ▼
AwaitFormOptions internal coroutine
        │
        ├─ RequestResponseBridge
        ├─ Child generators
        └─ AwaitForm driver
```

All option objects, child generators, and bridge state are strongly referenced by the internal AwaitFormOptions execution flow.

Coroutine suspension provided by AwaitGenerator keeps this object graph alive until the operation completes, fails, or is explicitly disposed.

As a result, object lifetime is primarily determined by coroutine lifetime rather than by traditional object ownership patterns.

# 1.1.0 Futures
## Nested Options

What should I do if I'm using object-oriented design, and I want to add elements but can't access the parent class?
Since version 1.1.0, this is now easy to achieve using nested options!

> [!TIP]  
> Nesting is allowed only one level deep.  
> Nested options are supported in menus as well  
> Also, the form respects all nested option keys, allowing you to map them accurately  

### main

```php
public function onUse(PlayerItemUseEvent $event) : void{
    $player = $event->getPlayer();
    if(!$player->isSneaking()){
        return;
    }
    Await::f2c(function() use ($player){
        while(true){
            try{
                $result = yield from AwaitFormOptions::sendFormAsync(
                    player: $player,
                    title: "Confirmation",
                    options: ["output" => new ConfirmInputForm()]
                );
                var_dump($result);
                //generator returns
                $typed = $result["output"]["confirm"];
                if(strtolower(trim($typed)) === "yes"){
                    $player->sendToastNotification("Confirmed", "Thanks for typing!");
                    break;
                }

            }catch(AwaitFormOptionsParentException $exception){
                if($exception->getCode() !== AwaitFormException::ERR_PLAYER_REJECTED){
                    break;
                }
            }
            $player->sendToastNotification("You must type 'yes'.", "please Type 'Yes'");
        }
    });
}
```

### ConfirmInputForm
```php
<?php

declare(strict_types=1);


namespace test\test;

use DaisukeDaisuke\AwaitFormOptions\FormOptions;
use cosmicpe\awaitform\FormControl;
use DaisukeDaisuke\AwaitFormOptions\exception\AwaitFormOptionsChildException;

class ConfirmInputForm extends FormOptions{
	/**
	 * @throws AwaitFormOptionsChildException
	 */
	public function confirmOnce(): \Generator {
		[$input] = yield from $this->request([
			FormControl::input("Type 'yes' to confirm", "yes", ""),
		]);
		return $input;
	}

	/**
	 * @throws AwaitFormOptionsChildException
	 */
	public function getOptions(): array {
		return [
			"entity" => new SimpleInput("nested!", "nested", "nested", 0),
			"confirm" => $this->confirmOnce(),
		];
	}

	protected function userDispose() : void{

	}
}
```

### output

```php
array(1) {
  ["output"]=>
  array(2) {
    ["entity"]=>
    array(2) {
      ["a"]=>
      string(6) "a"
      [0]=>
      string(6) "nested"
    }
    ["confirm"]=>
    string(3) "yes"
  }
}
```

## finalize()

How can you collect information from nested forms **after all forms have completed**?  
As of version 1.1.0, you can use `yield from $this->finalize(int $priority = 0);`!  
This allows your code block to pause until all other forms are either completed, finalized, or in an awaiting state—after which execution resumes!  
  
> [!TIP]  
> Lower numbers mean **lower priority**, and higher numbers mean **higher priority**   
> Although finalization is supported by menu as well, there is no point in calling it    
> However, in the form menu, if the option does nothing, you can also call this as a fake function

### ConfirmInputForm
```php
<?php

namespace test\test;

use DaisukeDaisuke\AwaitFormOptions\FormOptions;
use cosmicpe\awaitform\FormControl;
use DaisukeDaisuke\AwaitFormOptions\exception\AwaitFormOptionsChildException;

class ConfirmInputForm extends FormOptions{
	/**
	 * @throws AwaitFormOptionsChildException
	 */
	public function confirmOnce() : \Generator{
		[$input] = yield from $this->request([
			FormControl::input("Type 'yes' to confirm", "yes", ""),
		]);
		yield from $this->finalize(10000);//Awaiting other generators with priority 10000
		return $input;
	}

	/**
	 * @throws AwaitFormOptionsChildException
	 */
	public function getOptions() : array{
		return [
			"entity" => new SimpleInput("nested!", "nested", "nested", 0),
			"confirm" => $this->confirmOnce(),
		];
	}

	protected function userDispose() : void{

	}
}
```

## 1.3.0 Future
### schedule
Want to use some await before sending a request? Now you can with schedule() in 1.3.0!  

```php
<?php

namespace daisukedaisuke\test;

use cosmicpe\awaitform\MenuElement;
use DaisukeDaisuke\AwaitFormOptions\MenuOptions;

class HpBasedFoodOptions extends MenuOptions{
    /**
     * @throws AwaitFormOptionsChildException
     */
	public function giveRawFish1() : \Generator{
	    $this->schedule(); // This ensures that the awaitformoptions coroutine is temporarily suspended
	    //A few awaits
	    yield from $this->request([MenuElement::button("a"), 0]); // Here, the suspension is lifted
	}

    /**
     * @throws AwaitFormOptionsChildException
     */
	public function getOptions() : array{
		return [
			$this->giveRawFish1(),
		];
	}
	
	protected function userDispose() : void{
	    
	}
}
```

## 2.0.0 Future
### A new abstract has been added: userDispose
Each option must implement userDispose to handle garbage collection  
```php
protected function userDispose() : void{
	//As of 2.0.0, options must implement userDispose
}
```

### Memory leak fixed
Fixed gc leak (memory leak) when form is abandoned　　

## 3.0.0 Future 📌

* ➕ **AwaitFormOptionsParentException** has been added.
  This exception receives all non-fatal exceptions that occur during normal execution and may propagate to the parent coroutine.
  As such, it must be caught using a try-catch block, in the same manner as child-side exception handling.

* ➕ **AwaitFormOptionsChildException** has been added.
  This exception receives all non-fatal exceptions occurring on the child generator, such as disconnections, rejections, or coroutine aborts.
  Existing **AwaitFormException** error codes continue to be used.

* ❌ Dependency-related exception **AwaitFormException** is **no longer** used at the API level.

* ✨ However, the error id of the AwaitFormException is still used.

* ❌ The `neverRejects` and `throwExceptionInCaller` argument have been removed, as they cause severe phpstan warnings.
  Use try-catch instead.

* 🧨 **AwaitFormOptionsExpectedCrashException** has been added.
  This exception is intended to notify developers of invalid code structure or configuration mistakes and is recommended **not** to be caught.

* 🔗 **AwaitFormOptionsInvalidValueException** is now a subclass of **AwaitFormOptionsExpectedCrashException**.

* ❌ **AwaitFormOptionsAbortException** has been removed.
  It has been replaced by
  `ERR_COROUTINE_ABORTED` in **AwaitFormOptionsChildException**.

* 🧩 Some system-level methods in `DaisukeDaisuke/AwaitFormOptions/FormBridgeTrait.php`, which is an internal-use-only class and not part of the public API, have been changed to `protected`.
  This reduces IDE completion noise and improves productivity when writing code.

* 🛠️ Compatibility with **phpstan** has been improved.
  Depending on the phpstan configuration, missing try-catch blocks can now be detected.
  To enable this behavior, the following phpstan configuration is required:

  ```yaml
  parameters:
    level: 5
    exceptions:
      checkedExceptionClasses:
        - DaisukeDaisuke\AwaitFormOptions\exception\AwaitFormOptionsParentException
        - DaisukeDaisuke\AwaitFormOptions\exception\AwaitFormOptionsChildException
      uncheckedExceptionClasses:
        - DaisukeDaisuke\AwaitFormOptions\exception\AwaitFormOptionsExpectedCrashException
  ```
  * No more headaches over troublesome noise errors

* ⚠️ All exceptions, including user rejection, user logout, and cases where no option is selected, are now unconditionally propagated to both child and parent coroutines.
  As a result, all **AwaitGenerator** coroutines must now correctly implement try-catch handling.

  * The **parent coroutine** must implement:

    ```php
    } catch (FormValidationException | AwaitFormOptionsParentException) {
    ```

  * The **child coroutine** must implement:

    ```php
    } catch (AwaitFormOptionsChildException $e) {
    ```

    and may optionally branch logic based on error codes such as
    `AwaitFormOptionsChildException::ERR_COROUTINE_ABORTED` or
    `AwaitFormException::ERR_PLAYER_REJECTED`.

  * ✨ These changes improve consistency and make exceptional-flow handling easier to implement.

* 🧹 Addressed PHP 8.4 deprecations.

* 🔇 AwaitFormOptionsChildException's leaking from child coroutines are now silently ignored and no longer cause server crashes.
  * This behavior originated from an internal implementation bug related to preventing memory leaks. However, it was kept unchanged because it proved useful. This behavior will be preserved in the v3.0.0 series.

* ❌ The `neverRejects` parameter of the standalone functions `sendMenu` and `sendForm` has been removed for the same reasons described above.

# 4.0.0 Future
- dump AwaitForm 1.0.0
- The button class has been replaced by \cosmicpe\awaitform\MenuElement
- The number of elements available in MenuElement has increased
- phpdoc has been added for some APIs

# 4.0.3 Changelog
- ✨ `FormOptions` and `MenuOptions` can now call `yield from $this->finalize(int $priority = 0);`.
  The priority argument is passed to the internal bridge finalizer, where higher numbers are released first.
- 📝 README wording was clarified for standalone error handling, menu generator races, nested `getOptions()` values, child exception handling, option instance reuse, and post-`request()` synchronization.

# 4.0.4 Changelog
- 🐛 Fixed menu race return-value mapping when `schedule()` or another await delays a child generator before `request()`.
  Menu results are now stored by the actual request ID that was solved, not by the generator array index.
- 🧯 Aborted menu generators no longer overwrite the selected generator's return value when they catch `AwaitFormOptionsChildException` and return normally.
- 🧩 `FormOptions::getOptions()` may safely return `[]`.
  `sendFormAsync()` now preserves the top-level option key and returns an empty result array for that option.
- 🛡️ Form requests now reject `MenuElement` values early, and menu requests continue to require `MenuElement`.
  Invalid request tuples now stop as `AwaitFormOptionsExpectedCrashException` instead of continuing through parent-side assembly.
- 🔤 Added the correctly spelled `AwaitFormOptionsException` base class while keeping the existing `AwaitFormOptionsExcption` typo for compatibility.
- 🧪 Added PHPUnit coverage for request collection, menu race ID mapping, return storage, finalizer priority, rejection, abort, and invalid solve handling.
- phpdoc has been improved with GPT 5.5
