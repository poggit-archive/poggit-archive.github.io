<?php

namespace configlib;

use InvalidArgumentException;
use JsonException;
use ReflectionClass;

class Configuration {

    public const array KNOWN_TYPES = [
        Configuration::TYPE_YAML, Configuration::TYPE_JSON
    ];

    public const int TYPE_YAML = 0;
    public const int TYPE_JSON = 1;

    public function __construct(
        private readonly string $path,
        private readonly int $type,
        private readonly int $jsonOptions = JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
    ) {
        if (!in_array($this->getType(), self::KNOWN_TYPES)) {
            throw new InvalidArgumentException("Unknown configuration type");
        }
    }

    /**
     * @throws JsonException
     */
    public function load(): bool {
        if (file_exists($this->getPath()) && is_file($this->getPath())) {
            $contents = file_get_contents($this->getPath());
            $contents = ($this->getType() == Configuration::TYPE_YAML ? yaml_parse($contents) : json_decode($contents, true, flags: JSON_THROW_ON_ERROR));

            foreach (new ReflectionClass($this)->getProperties() as $property) {
                if (!str_contains($property->getDocComment(), "@ignored")) {
                    $property->setAccessible(true);
                    if (array_key_exists($property->getName(), $contents)) {
                        $property->setValue($this, $contents[$property->getName()]);
                    }
                }
            }

            return true;
        }
        return false;
    }

    private function extractComments(string $docComment): array {
        $comments = [];

        if (preg_match_all("/@comment\s+(.+)$/m", $docComment, $matches)) {
            foreach ($matches[1] as $comment) {
                $comments[] = trim($comment);
            }
        }

        return $comments;
    }

    private function insertYamlComments(string $yaml, array $comments): string {
        $lines = explode("\n", $yaml);
        $result = [];

        foreach ($lines as $line) {
            if (preg_match("/^([a-zA-Z_][a-zA-Z0-9_]*):/", $line, $matches)) {
                $key = $matches[1];

                if (!empty($comments[$key])) {
                    foreach ($comments[$key] as $comment) $result[] = '# ' . $comment;
                }
            }

            $result[] = $line;
        }

        return implode("\n", $result);
    }

    /**
     * @throws \JsonException
     */
    public function save(): bool {
        $contents = [];
        $comments = [];

        foreach (new ReflectionClass($this)->getProperties() as $property) {
            if (!str_contains($property->getDocComment(), "@ignored")) {
                $property->setAccessible(true);
                $propertyName = $property->getName();
                $contents[$propertyName] = $property->getValue($this);
                $docComment = $property->getDocComment();
                if ($docComment !== false) {
                    $extractedComments = $this->extractComments($docComment);
                    if (!empty($extractedComments)) $comments[$propertyName] = $extractedComments;
                }
            }
        }

        if ($this->getType() == Configuration::TYPE_YAML) {
            $yamlOutput = yaml_emit($contents, YAML_UTF8_ENCODING);
            $yamlOutput = $this->insertYamlComments($yamlOutput, $comments);
            return file_put_contents($this->getPath(), $yamlOutput) !== false;
        } else {
            $jsonContent = json_encode($contents, $this->jsonOptions | JSON_THROW_ON_ERROR);
            return file_put_contents($this->getPath(), $jsonContent) !== false;
        }
    }

    public function getPath(): string {
        return $this->path;
    }

    public function getType(): int {
        return $this->type;
    }
}