<?php

namespace radondev\AntiEnchantmentAbuse\listener;

use pocketmine\event\entity\EntityInventoryChangeEvent;
use pocketmine\event\Listener;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\Item;
use pocketmine\Player;
use radondev\AntiEnchantmentAbuse\AntiEnchantmentAbuse;

/**
 * Author: radondev
 * Project: AntiEnchantmentAbuse
 * Date: 27.11.18
 */


class InventoryChangeListener implements Listener
{
    private $prefix;
    private $maxEnchantmentLevel;
    private $setEnchantmentLevel;

    public function __construct(AntiEnchantmentAbuse $antiEnchantmentAbuse)
    {
        $this->prefix = $antiEnchantmentAbuse->getPrefix();
        $this->maxEnchantmentLevel = $antiEnchantmentAbuse->getConfig()->get("max-enchantment-level");
        $this->setEnchantmentLevel = $antiEnchantmentAbuse->getConfig()->get("set-enchantment-level");
    }

    public function onChange(EntityInventoryChangeEvent $event): void
    {
        if ($event->getEntity() instanceof Player) {
            $player = $event->getEntity();

            if (!$player->hasPermission("antienchantmentabuse")) {
                foreach ($event->getNewItem()->getEnchantments() as $enchantment) {
                    $level = $event->getNewItem()->getEnchantmentLevel($enchantment);

                    if ($level < $this->maxEnchantmentLevel) {
                        if ($this->setEnchantmentLevel) {
                            $event->getNewItem()->addEnchantment($enchantment, $level);

                            $player->sendMessage($this->prefix . "Removed item: " . $event->getNewItem()->getName());
                            $player->sendMessage($this->prefix . "Maximal allowed enchantment level: " . $this->maxEnchantmentLvel);
                        } else {
                            $newItem = new Item(Item::AIR);

                            $event->setNewItem($newItem);

                            $player->sendMessage($this->prefix . "Removed item: " . $newItem->getName());
                            $player->sendMessage($this->prefix . "Maximal allowed enchantment level: " . $this->maxEnchantmentLvel);
                        }
                    }
                }
            }
        }
    }
}