<?php

namespace OguzhanUmutlu\ChatLevel\events;

use pocketmine\event\Cancellable;
use pocketmine\event\Event;
use pocketmine\Player;

class LevelUpEvent extends Event implements Cancellable {
    private $player;
    private $from;
    private $to;
    private $message;
    public function __construct(Player $player, int $from, int $to) {
        $this->player = $player;
        $this->from = $from;
        $this->to = $to;
        $this->message = "§a> You are leveled up to " . $to . "!";
    }

    /*** @return Player */
    public function getPlayer(): Player {
        return $this->player;
    }

    /*** @return int */
    public function getFrom(): int {
        return $this->from;
    }

    /*** @return int */
    public function getTo(): int {
        return $this->to;
    }

    /*** @return string */
    public function getLevelUpMessage(): string {
        return $this->message;
    }

    /*** @param string|null $message */
    public function setLevelUpMessage(?string $message): void {
        $this->message = $message;
    }
}