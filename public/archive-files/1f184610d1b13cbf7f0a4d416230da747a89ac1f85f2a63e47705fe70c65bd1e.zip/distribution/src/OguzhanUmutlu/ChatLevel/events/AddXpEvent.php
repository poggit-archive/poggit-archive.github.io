<?php

namespace OguzhanUmutlu\ChatLevel\events;

use pocketmine\event\Cancellable;
use pocketmine\event\Event;
use pocketmine\Player;

class AddXpEvent extends Event implements Cancellable {
    private $player;
    private $from;
    private $to;
    public function __construct(Player $player, int $from, int $to) {
        $this->player = $player;
        $this->from = $from;
        $this->to = $to;
    }

    /*** @return Player */
    public function getPlayer(): Player {
        return $this->player;
    }

    /*** @return int */
    public function getFrom(): int {
        return $this->from;
    }

    /*** @return int */
    public function getTo(): int {
        return $this->to;
    }

    /*** @return bool */
    public function willLevelUp(): bool {
        return $this->to >= 100;
    }
}