<?php

namespace OguzhanUmutlu\ChatLevel;

use OguzhanUmutlu\ChatLevel\events\AddXpEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;

class EventListener implements Listener {
    public function onChat(PlayerChatEvent $event) {
        $ev = new AddXpEvent($event->getPlayer(), LevelManager::getXp($event->getPlayer()), LevelManager::getXp($event->getPlayer())+1);
        $ev->call();
        if(!$ev->isCancelled())
            LevelManager::addXp($event->getPlayer());
    }
}