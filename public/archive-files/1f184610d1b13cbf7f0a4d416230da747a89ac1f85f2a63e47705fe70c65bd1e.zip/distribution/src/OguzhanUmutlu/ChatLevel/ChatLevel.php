<?php

namespace OguzhanUmutlu\ChatLevel;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

class ChatLevel extends PluginBase {
    /*** @var ChatLevel|null */
    private static $instance = null;
    /*** @var Config|null */
    private $dataConfig = null;
    public function onEnable() {
        self::$instance = $this;
        $this->dataConfig = new Config($this->getDataFolder() . "data.yml");
        $this->getServer()->getPluginManager()->registerEvents(new EventListener(), $this);
    }

    /*** @return Config|null */
    public function getDataConfig(): ?Config {
        return $this->dataConfig;
    }

    /*** @return ChatLevel|null */
    public static function getInstance(): ?ChatLevel {
        return self::$instance;
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if($command->getName() != "chat"."level") return true;
        if(!$sender instanceof Player) {
            $sender->sendMessage("§c> Use this command in-game.");
            return true;
        }
        $sender->sendMessage("§e> Your xp: ".LevelManager::getXp($sender)."/100, your level: ".LevelManager::getLevel($sender));
        return true;
    }
}