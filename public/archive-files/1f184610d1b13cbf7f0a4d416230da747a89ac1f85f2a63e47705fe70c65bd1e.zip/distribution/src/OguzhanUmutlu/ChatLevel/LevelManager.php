<?php

namespace OguzhanUmutlu\ChatLevel;

use OguzhanUmutlu\ChatLevel\events\LevelUpEvent;
use pocketmine\Player;

class LevelManager {
    public static function getXp(Player $player): int {
        return ChatLevel::getInstance()->getDataConfig()->getNested($player->getName().".xp", 0);
    }
    public static function getLevel(Player $player): int {
        return ChatLevel::getInstance()->getDataConfig()->getNested($player->getName().".level", 1);
    }
    public static function addXp(Player $player): void {
        ChatLevel::getInstance()->getDataConfig()->setNested($player->getName().".xp", self::getXp($player)+1);
        ChatLevel::getInstance()->getDataConfig()->save();
        ChatLevel::getInstance()->getDataConfig()->reload();
        if(self::getXp($player) >= 100) {
            $ev = new LevelUpEvent($player, self::getLevel($player), self::getLevel($player)+1);
            $ev->call();
            if($ev->isCancelled())
                return;
            ChatLevel::getInstance()->getDataConfig()->setNested($player->getName().".xp", self::getXp($player)-100);
            ChatLevel::getInstance()->getDataConfig()->save();
            ChatLevel::getInstance()->getDataConfig()->reload();
            self::addLevel($player);
            if($ev->getLevelUpMessage() && strlen($ev->getLevelUpMessage()) > 0)
                $player->sendMessage($ev->getLevelUpMessage());
        }
    }
    public static function addLevel(Player $player): void {
        ChatLevel::getInstance()->getDataConfig()->setNested($player->getName().".level", self::getLevel($player)+1);
        ChatLevel::getInstance()->getDataConfig()->save();
        ChatLevel::getInstance()->getDataConfig()->reload();
    }
}