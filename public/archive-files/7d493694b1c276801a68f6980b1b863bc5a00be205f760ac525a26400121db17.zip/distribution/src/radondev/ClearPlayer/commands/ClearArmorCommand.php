<?php


namespace radondev\ClearPlayer\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginIdentifiableCommand;
use pocketmine\plugin\Plugin;
use radondev\ClearPlayer\ClearPlayer;

/**
 * Author: radondev
 * Project: ClearPlayer
 * Date: 05.11.18
 */
class ClearArmorCommand extends Command implements PluginIdentifiableCommand
{
    /**
     * @var string $prefix
     */
    private $prefix;

    /**
     * @var bool|mixed $notify
     */
    private $notify;

    /**
     * @var bool|mixed $notify_by
     */
    private $notify_by;

    public function __construct()
    {
        parent::__construct("cleararmor", "Clears a players armor", "/cleararmor <Player>");

        $this->prefix = ClearPlayer::getInstance()->getConfig()->get("prefix");
        $this->notify = ClearPlayer::getInstance()->getConfig()->get("notify");
        $this->notify_by = ClearPlayer::getInstance()->getConfig()->get("notify-by");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool
    {
        if (isset($args[0])) {
            if ($sender->hasPermission("clearplayer.command.cleararmor")) {
                if (ClearPlayer::getInstance()->getServer()->getPlayer($args[0]) != null) {
                    $player = ClearPlayer::getInstance()->getServer()->getPlayer($args[0]);
                    $player->getArmorInventory()->clearAll();
                    $sender->sendMessage($this->prefix . " Cleared " . $player->getName() . "'s armor.");

                    if ($this->notify) {
                        if ($this->notify_by) {
                            $player->sendMessage($this->prefix . " Your Inventory has been cleared by " . $sender->getName() . ".");
                        } else {
                            $player->sendMessage($this->prefix . " Your Inventory has been cleared.");
                        }
                    }
                    return true;
                } else {
                    $sender->sendMessage($this->prefix . " That is not a valid player.");
                    return true;
                }
            } else {
                $sender->sendMessage($this->prefix . " You have no permission to perform this command.");
                return true;
            }
        } else {
            $sender->sendMessage($this->prefix . " /cleararmor <Player>");
            return true;
        }
    }

    public function getPlugin(): Plugin
    {
        return ClearPlayer::getInstance();
    }
}