<?php

namespace radondev\ClearPlayer;

use pocketmine\command\CommandMap;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\PluginLogger;
use radondev\ClearPlayer\commands\ClearArmorCommand;
use radondev\ClearPlayer\commands\ClearInventoryCommand;

/**
 * Author: radondev
 * Project: ClearPlayer
 * Date: 05.11.18
 */
class ClearPlayer extends PluginBase
{
    /**
     * @var ClearPlayer $instance
     */
    private static $instance;

    /**
     * @var PluginLogger $logger
     */
    private $logger;

    /**
     * @var CommandMap $commandMap
     */
    private $commandMap;

    public function onEnable(): void
    {
        self::$instance = $this;
        $this->logger = $this->getLogger();
        $this->commandMap = $this->getServer()->getCommandMap();

        @mkdir($this->getDataFolder());
        $this->saveDefaultConfig();

        $this->commandMap->register("cleararmor", new ClearArmorCommand());
        $this->commandMap->register("clearinventory", new ClearInventoryCommand());

        $this->logger->info("Enabled ClearPlayer [" . $this->getDescription()->getVersion() . "] made by radondev");
    }

    public function onDisable(): void
    {
        $this->logger->info("Disabled ClearPlayer [" . $this->getDescription()->getVersion() . "] made by radondev");
    }

    public static function getInstance(): ClearPlayer
    {
        return self::$instance;
    }
}