Source recovered from an original archived PHAR.

distribution/ contains every regular file from the PHAR, byte for byte.
The plugin and its PHAR stub were not executed.
RECOVERY.json records the original PHAR SHA-256, release, source attribution, license and per-file hashes.

This is a preserved distribution tree. Repository files excluded by the build are unavailable here;
build-time version changes and bundled or shaded libraries may be present.
The recorded build commit comes from Poggit metadata and does not establish a complete Git source snapshot.
