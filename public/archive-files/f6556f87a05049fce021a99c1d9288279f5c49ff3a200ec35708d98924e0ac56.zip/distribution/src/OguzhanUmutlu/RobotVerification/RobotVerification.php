<?php

namespace OguzhanUmutlu\RobotVerification;

use OguzhanUmutlu\RobotVerification\libs\muqsit\invmenu\inventory\InvMenuInventory;
use OguzhanUmutlu\RobotVerification\libs\muqsit\invmenu\InvMenu;
use OguzhanUmutlu\RobotVerification\libs\muqsit\invmenu\InvMenuHandler;
use OguzhanUmutlu\RobotVerification\libs\muqsit\invmenu\transaction\DeterministicInvMenuTransaction;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\inventory\InventoryPickupArrowEvent;
use pocketmine\event\inventory\InventoryPickupItemEvent;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\Item;
use pocketmine\item\ItemIds;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;

class RobotVerification extends PluginBase implements Listener {
    public function onEnable() {
        if(class_exists(InvMenuHandler::class) && !InvMenuHandler::isRegistered()) InvMenuHandler::register($this);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }
    public $closed = [];
    public function onJoin(PlayerJoinEvent $e) {
        $player = $e->getPlayer();
        $menu = InvMenu::create(InvMenu::TYPE_CHEST);
        for($i=0;$i<27;$i++){
            $menu->getInventory()->setItem($i, (new Item(ItemIds::STAINED_GLASS_PANE, rand(0, 15)))->setCustomName("§r"));
        }
        $colors = ["white", "orange", "lightpurple", "lightblue", "yellow", "lightgreen", "pink", "darkgray", "lightgray", "cyan", "purple", "blue", "brown", "darkgreen", "red", "black"];
        $color = $colors[random_int(0, count($colors)-1)];
        $menu->getInventory()->setItem(random_int(0, 26), (new Item(ItemIds::STAINED_GLASS_PANE, array_search($color, $colors)))->setCustomName("§r"));
        $menu->setName("Select ".$color);
        $menu->setListener(InvMenu::readonly(function (DeterministicInvMenuTransaction $transaction)use($color,$colors) : void {
            $player = $transaction->getPlayer();
            if($transaction->getItemClicked()->getDamage() != array_search($color, $colors)) {
                $player->kick("Wrong color!", false);
            } else {
                unset($this->closed[$player->getName()]);
                $player->removeAllWindows();
            }
        }));
        $menu->setInventoryCloseListener(function(Player $player, InvMenuInventory $inventory)use($menu){
            if(isset($this->closed[$player->getName()])) {
                $menu->send($player);
            }
        });
        $menu->send($player);
        $this->closed[$player->getName()] = true;
    }
    public function onQuit(PlayerQuitEvent $e) {
        if(isset($this->closed[$e->getPlayer()->getName()])) unset($this->closed[$e->getPlayer()->getName()]);
    }
    public function onInteract(PlayerInteractEvent $e) {
        if(isset($this->closed[$e->getPlayer()->getName()])) $e->setCancelled(true);
    }
    public function onBreak(BlockBreakEvent $e) {
        if(isset($this->closed[$e->getPlayer()->getName()])) $e->setCancelled(true);
    }
    public function onPlace(BlockPlaceEvent $e) {
        if(isset($this->closed[$e->getPlayer()->getName()])) $e->setCancelled(true);
    }
    public function onMove(PlayerMoveEvent $e) {
        if(isset($this->closed[$e->getPlayer()->getName()])) $e->setCancelled(true);
    }
    public function onItemTake(InventoryPickupItemEvent $e) {
        foreach($e->getViewers() as $player) {
            if(isset($this->closed[$player->getName()])) $e->setCancelled(true);
        }
    }
    public function onItemDrop(PlayerDropItemEvent $e) {
        if(isset($this->closed[$e->getPlayer()->getName()])) $e->setCancelled(true);
    }
    public function onTransaction(InventoryTransactionEvent $e) {
        if(isset($this->closed[$e->getTransaction()->getSource()->getName()])) $e->setCancelled(true);
    }
    public function onArrowTake(InventoryPickupArrowEvent $e) {
        foreach($e->getViewers() as $player) {
            if(isset($this->closed[$player->getName()])) $e->setCancelled(true);
        }
    }
}