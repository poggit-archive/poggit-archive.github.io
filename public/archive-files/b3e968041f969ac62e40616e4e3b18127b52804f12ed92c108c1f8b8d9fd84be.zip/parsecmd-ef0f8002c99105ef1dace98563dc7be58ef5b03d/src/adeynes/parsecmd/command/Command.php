<?php
declare(strict_types=1);

namespace adeynes\parsecmd\command;

use adeynes\parsecmd\command\blueprint\CommandBlueprint;
use adeynes\parsecmd\form\CommandForm;
use pocketmine\command\Command as PMCommand;
use pocketmine\command\CommandSender;
use pocketmine\plugin\PluginOwned;
use pocketmine\command\utils\InvalidCommandSyntaxException;
use pocketmine\player\Player;
use pocketmine\plugin\Plugin;

abstract class Command extends PMCommand implements PluginOwned
{

    /** @var Plugin */
    protected Plugin $plugin;

    /** @var CommandBlueprint */
    protected CommandBlueprint $blueprint;

    protected function __construct(Plugin $plugin, CommandBlueprint $blueprint, string $name,
                                   string $permission = null, string $description = '', string $usage = null) {
        $this->plugin = $plugin;
        $this->blueprint = $blueprint;
        $this->setPermission($permission);
        parent::__construct($name, $description, $usage ?? $blueprint->getUsage());
    }

    public function getPlugin(): Plugin
    {
        return $this->plugin;
    }

    public function getBlueprint(): CommandBlueprint
    {
        return $this->blueprint;
    }

    /**
     * This contains boilerplate code e.g. permission checking, and runs _execute()
     * @param CommandSender $sender
     * @param string $label
     * @param array $arguments
     * @return bool
     */
    public function execute(CommandSender $sender, string $label, array $arguments): bool
    {
        if (!$this->testPermission($sender)) return false;

        $command = CommandParser::parse($this, $arguments);
        if ($command->getArgumentCount() < $this->getBlueprint()->getMinimumArgumentCount()) {
            if (!$sender instanceof Player) throw new InvalidCommandSyntaxException;

            $form = (new CommandForm())
                ->setCommandName($this->getName())
                ->setTitle(strtoupper($this->getName()));
            $this->getBlueprint()->populateForm($form)->send($sender);
            return false;
        }

        return $this->_execute($sender, $command);
    }

    abstract public function _execute(CommandSender $sender, ParsedCommand $command): bool;

}
