<?php


namespace OguzhanUmutlu\OneBlockAFK;

use pocketmine\command\ConsoleCommandSender;
use pocketmine\scheduler\Task;
use pocketmine\Player;

class AfkTask extends Task {
    public $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function getBoundingBlocks(Player $player): array {
        $AABB = $player->getBoundingBox()->expandedCopy(0, 1, 0);
        $AABB->maxY = $player->getY();
        return $player->getLevel()->getCollisionBlocks($AABB);
    }

    public function onRun(int $currentTick): void {
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {

            $blocks = $this->getBoundingBlocks($player);
            if (!isset($this->plugin->data[strtolower($player->getName())])) {
                $data = array_map(function ($n) {
                    return ["x" => $n->getX(), "y" => $n->getY(), "z" => $n->getZ(), "level" => $n->getLevel()->getFolderName(), "start" => time()];
                }, $blocks);
                $this->plugin->data[strtolower($player->getName())] = $data;
            } else {
                $data = $this->plugin->data[strtolower($player->getName())];
            }
            foreach($blocks as $x) {
                $blocksMapXyzY = array_map(function ($n) {
                    return [$n["x"], $n["y"], $n["z"], $n["level"]];
                }, $data);
                $a = ["x" => $x->getX(), "y" => $x->getY(), "z" => $x->getZ(), "level" => $x->getLevel()->getFolderName(), "start" => time()];
                if (!in_array([$x->getX(), $x->getY(), $x->getZ(), $x->getLevel()->getFolderName()], $blocksMapXyzY)) {
                    array_push($data, $a);
                    array_push($this->plugin->data[strtolower($player->getName())], $a);
                }
            }
            $blocksMapXyz = array_map(function ($n) {
                return $n->getX().":".$n->getY().":".$n->getZ().":".$n->getLevel()->getFolderName();
            }, $blocks);
            foreach ($data as $index => $x) {
                if (!in_array($x["x"].":".$x["y"].":".$x["z"].":".$x["level"], $blocksMapXyz)) {
                    unset($data[$index]);
                    unset($this->plugin->data[strtolower($player->getName())][$index]);
                }
            }

            foreach ($this->plugin->getConfig()->getNested("alerts") as $alert) {
                if (isset($data[0]) && time() > $data[0]["start"] + (int)$alert["wait"]) {
                    foreach ($alert["commands"] as $cmd) {
                        $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), str_replace("{player}", $player->getName(), $cmd));
                    }
                }
            }
        }
    }
}
