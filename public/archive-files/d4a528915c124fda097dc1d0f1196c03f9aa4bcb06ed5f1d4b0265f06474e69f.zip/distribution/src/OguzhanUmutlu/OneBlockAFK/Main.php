<?php


namespace OguzhanUmutlu\OneBlockAFK;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;

class Main extends PluginBase implements Listener {
    public $data = [];

    public function onEnable(): void {
        $this->saveDefaultConfig();
        $this->getScheduler()->scheduleRepeatingTask(new AfkTask($this), 20);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $player = $event->getPlayer();
        if (isset($this->data[strtolower($player->getName())])) {
            unset($this->data[strtolower($player->getName())]);
        }
    }
}
