<?php

namespace OguzhanUmutlu\CommandEditor;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\event\Listener;
use pocketmine\event\plugin\PluginEnableEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

class CommandEditor extends PluginBase implements Listener {
    /**
     * @var Command[]
     */
    public $disabled = [];
    /**
     * @var array[]
     */
    public $log = [];
    /**
     * @var array[]
     */
    public $default = [];
    public function onEnable() {
        foreach($this->getServer()->getCommandMap()->getCommands() as $cmd) {
            $this->default[$cmd->getName()] = [
                "description" => $cmd->getDescription(),
                "aliases" => $cmd->getAliases(),
                "permission" => $cmd->getPermission(),
                "permissionmessage" => $cmd->getPermissionMessage(),
                "disabled" => false
            ];
        }
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onPluginLoad(PluginEnableEvent $e) {
        $dis = array_filter($this->getServer()->getPluginManager()->getPlugins(), function($n){return !$n->isEnabled();});
        if(count($dis) < 1) {
            $attempts = new Config($this->getDataFolder() . "attempts.json", Config::JSON, []);
            $this->log = $attempts->getAll();
            foreach($this->log as $cmd => $attempt) {
                foreach($attempt as $a => $b) {
                    // added true option to the end of the command so it will not send unnecessary messages
                    // ik i can do it with making an api but, IM LAZY lol
                    $this->onCommand(null, $this->getServer()->getCommandMap()->getCommand("commandeditor"), "", explode(" ", $cmd." ".($a == "disabled" && $b ? "disable" : $a." ".(is_array($b) ? implode(",",$b) : $b))." /*-+WillNotHappen+-*/"));
                }
            }
        }
    }

    public function onDisable() {
        $attempts = new Config($this->getDataFolder() . "attempts.json", Config::JSON, []);
        $attempts->setAll($this->log);
        $attempts->save();
    }

    public function onCommand(?CommandSender $sender, Command $command, string $label, array $args): bool
    {
        if ($command->getName() != "commandeditor") return true;
        $x = $sender;
        $afix = $args;
        if(empty($afix)) $afix = [""];
        if($afix[count($afix)-1] == "/*-+WillNotHappen+-*/" && !$sender instanceof ConsoleCommandSender) $afix[count($afix)-1] = "no.";
        if (!isset($args[0])) {
            if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§c> Usage: /commandeditor <(commandName), enabledlist, disabledlist" . "> <description, aliases, permission, permissionmessage, reset>");
            return true;
        }
        $args[0] = strtolower($args[0]);
        if ($args[0] == "enabledlist") {
            if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§a> Enabled commands: §b" . implode("§a, §b", array_map(function ($n) {
                    return $n->getName();
                }, $this->getServer()->getCommandMap()->getCommands())));
        } else if ($args[0] == "disabledlist") {
            if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§a> Disabled commands: §b" . implode("§a, §b", array_map(function ($n) {
                    return $n->getName();
                }, $this->disabled)));
        } else {
            $selected = $this->getServer()->getCommandMap()->getCommand($args[0]);
            if (!$selected) {
                foreach ($this->disabled as $name => $a) {
                    if ($name == $args[0]) $selected = $a;
                }
            }
            if (!$selected) {
                if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§c> §b" . $args[0] . "§c command not found.");
                return true;
            }
            if ($args[0] == $command->getName()) {
                if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§c> You cannot edit main command!");
                return true;
            }
            if (!isset($args[1])) {
                if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§c> Usage: /commandeditor " . $args[0] . " <description, aliases, permission, permissionmessage, disable, enable, reset> <value, (or nothing)" . ">");
                return true;
            }
            if ($args[1] == "description") {
                if (!$this->getServer()->getCommandMap()->getCommand($args[0])) {
                    if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§c> This command is disabled.");
                    return true;
                }
                if (!isset($args[2])) {
                    if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§a> §b" . $args[0] . "§a's description: §b" . $selected->getDescription());
                    return true;
                }
                $this->logF($args, $selected);
                $selected->setDescription($args[2]);
                $this->update();
                if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§a> §b" . $args[0] . "§a's description set to §b" . $selected->getDescription());
            } else if ($args[1] == "aliases") {
                if (!$this->getServer()->getCommandMap()->getCommand($args[0])) {
                    if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§c> This command is disabled.");
                    return true;
                }
                if (!isset($args[2])) {
                    if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§a> §b" . $args[0] . "§a's aliases: §b" . implode("§a, §b", $selected->getAliases()));
                    return true;
                }
                $arg = $args;
                $arg[2] = explode(",", $args[2]);
                $this->logF($arg, $selected);
                $selected->setAliases(explode(",", $args[2]));
                $this->update();
                if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§a> §b" . $args[0] . "§a's aliases set to §b" . implode("§a, §b", $selected->getAliases()) . "\n§e> Tip: Use , to add more than one alias.");
            } else if ($args[1] == "permission") {
                if (!$this->getServer()->getCommandMap()->getCommand($args[0])) {
                    if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§c> This command is disabled.");
                    return true;
                }
                if (!isset($args[2])) {
                    if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§a> §b" . $args[0] . "§a's permission: §b" . ($selected->getPermission() ?? "§cnone"));
                    return true;
                }
                $arg = $args;
                $arg[2] = $args[2] == "none" ? null : $args[2];
                $this->logF($arg, $selected);
                $selected->setPermission($args[2] == "none" ? null : $args[2]);
                $this->update();
                if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§a> §b" . $args[0] . "§a's permission set to §b" . ($selected->getPermission() ?? "§cnone") . "\n§e> Tip: Type none to remove permission.");
            } else if ($args[1] == "permissionmessage") {
                if (!$this->getServer()->getCommandMap()->getCommand($args[0])) {
                    if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§c> This command is disabled.");
                    return true;
                }
                if (!isset($args[2])) {
                    if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§a> §b" . $args[0] . "§a's permission message: §b" . ($selected->getPermissionMessage() ?? "§cnone"));
                    return true;
                }
                $arg = $args;
                $arg[2] = $args[2] == "none" ? null : $args[2];
                $this->logF($arg, $selected);
                $selected->setPermissionMessage($args[2] == "none" ? null : $args[2]);
                $this->update();
                if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§a> §b" . $args[0] . "§a's permission message set to §b" . ($selected->getPermissionMessage() ?? "§cnone") . "\n§e> Tip: Type none to remove permission.");
            } else if ($args[1] == "enable") {
                if ($this->getServer()->getCommandMap()->getCommand($args[0])) {
                    if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§c> This command is already enabled.");
                    return true;
                }
                if (!isset($this->disabled[$args[0]])) {
                    if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§c> Command not found.");
                    return true;
                }
                $this->getServer()->getCommandMap()->register($this->getName(), $this->disabled[$args[0]]);
                unset($this->disabled[$args[0]]);
                $this->update();
                $this->logF([null,"disabled",false], $selected);
                if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§a> Command named §b" . $args[0] . "§a successfully enabled.");
            } else if ($args[1] == "disable") {
                if (!$this->getServer()->getCommandMap()->getCommand($args[0])) {
                    if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§c> This command is already disabled or not found.");
                    return true;
                }
                $this->disabled[$args[0]] = $selected;
                $this->getServer()->getCommandMap()->unregister($selected);
                $this->update();
                $this->logF([null,"disabled",true], $selected);
                if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§a> Command named §b" . $args[0] . "§a successfully disabled.");
            } else if ($args[1] == "reset") {
                unset($this->log[$selected->getName()]);
                foreach($this->default[$selected->getName()] as $name => $var) {
                    $this->logF([null,$name,$var], $selected);
                }
                $selected->setDescription($this->default[$selected->getName()]["description"]);
                $selected->setAliases($this->default[$selected->getName()]["aliases"]);
                $selected->setPermission($this->default[$selected->getName()]["permission"]);
                $selected->setPermissionMessage($this->default[$selected->getName()]["permissionmessage"] ?? "");
                $this->update();
                if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§a> Command named §b" . $args[0] . "§a has been reset.");
            } else {
                if ($x && $afix[count($afix)-1] != "/*-+WillNotHappen+-*/") $sender->sendMessage("§c> Usage: /commandeditor §b" . $selected->getName() . "§c <description, aliases, permission, permissionmessage, reset>");
            }
        }
        return true;
    }
    public function update(){
        foreach($this->getServer()->getOnlinePlayers() as $player) {
            $player->sendCommandData();
        }
    }
    public function logF($args, Command $selected) { //ik it sucks lol
        if(!isset($this->log[$selected->getName()])) $this->log[$selected->getName()] = $this->default[$selected->getName()];
        $this->log[$selected->getName()][$args[1]] = $args[2];
    }
}
