<?php

namespace OguzhanUmutlu\StopLag;

use pocketmine\event\block\BlockBurnEvent;
use pocketmine\event\block\BlockGrowEvent;
use pocketmine\event\block\BlockSpreadEvent;
use pocketmine\event\block\BlockUpdateEvent;
use pocketmine\event\entity\EntityBlockChangeEvent;
use pocketmine\event\entity\EntityDamageByChildEntityEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Event;
use pocketmine\level\Position;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\{CommandSender, Command};

class StopLag extends PluginBase implements Listener {
    public $stoppedLevels = [];
    public function onEnable() {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }
    public function check(Position $pos, Event $event) {
        if(isset($this->stoppedLevels[$pos->getLevel()->getFolderName()])) {
            if(($event instanceof EntityDamageByEntityEvent || $event instanceof EntityDamageByChildEntityEvent)) {
                $event->setKnockBack(0);
            } else {
                $event->setCancelled(true);
            }
        }
    }
    public function a(BlockBurnEvent $e) {
        $this->check($e->getBlock(), $e);
    }
    public function b(BlockGrowEvent $e) {
        $this->check($e->getBlock(), $e);
    }
    public function c(BlockSpreadEvent $e) {
        $this->check($e->getBlock(), $e);
    }
    public function d(BlockUpdateEvent $e) {
        $this->check($e->getBlock(), $e);
    }
    public function e(EntityBlockChangeEvent $e) {
        $this->check($e->getEntity(), $e);
    }
    public function f(EntityDamageEvent $e) {
        if((!$e instanceof EntityDamageByEntityEvent && !$e instanceof EntityDamageByChildEntityEvent) || !$e->getEntity() instanceof Player) return;
        $this->check($e->getEntity(), $e);
    }
    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
		if($command->getName() == "stoplag") {
            if(!isset($args[0]) || !isset($args[1]) || !in_array($args[1], ["true", "false"])) {
                $sender->sendMessage("§c> Usage: /stoplag <levelFolderName, * (all levels)> <true, false>");
                return true;
            }
            $res = $args[0] == "*" ? $this->getServer()->getLevels() : [];
            if($this->getServer()->getLevelByName($args[0])) $res[] = $this->getServer()->getLevelByName($args[0]);
            if(empty($res)) {
                $sender->sendMessage("§c> Level by folder name not found.");
                return true;
            }
            foreach($res as $x) {
                if($args[1] == "false") {
                    if(isset($this->stoppedLevels[$x->getFolderName()])) {
                        unset($this->stoppedLevels[$x->getFolderName()]);
                        $sender->sendMessage("§a> Stop lag disabled in ".$x->getFolderName());
                    }
                } else {
                    if(!isset($this->stoppedLevels[$x->getFolderName()])) {
                        $this->stoppedLevels[$x->getFolderName()] = $x->getFolderName();
                        $sender->sendMessage("§a> Stop lag enabled in ".$x->getFolderName());
                    }
                }
            }
        } else if($command->getName() == "stoplaglist") {
		    $sender->sendMessage("§e> (".count($this->stoppedLevels).")All stop-lag worlds: ".(empty($this->stoppedLevels) ? "None" : implode(", ", $this->stoppedLevels)));
        }
		return true;
	}
}
