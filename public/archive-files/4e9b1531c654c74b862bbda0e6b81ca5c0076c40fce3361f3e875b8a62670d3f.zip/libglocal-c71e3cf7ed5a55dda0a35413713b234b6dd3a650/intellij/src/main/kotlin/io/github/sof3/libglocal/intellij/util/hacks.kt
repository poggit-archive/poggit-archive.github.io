package io.github.sof3.libglocal.intellij.util

/*
 * libglocal
 *
 * Copyright 2018 SOFe
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

fun never(message: String = "Unexpected control flow") : Nothing = throw AssertionError(message)

/**
 * Used when a value is required somewhere logically dead, such as the else branch of a "when" where kotlin cannot detect its exhaustiveness properly
 */
val NEVER: Nothing get() = never()
