<?php

namespace OguzhanUmutlu\ChorusPlant;

use OguzhanUmutlu\ChorusPlant\block\ChorusFlower;
use OguzhanUmutlu\ChorusPlant\block\ChorusPlant;
use pocketmine\block\Block;
use pocketmine\block\BlockFactory;
use pocketmine\item\Item;
use pocketmine\plugin\PluginBase;

class ChorusMain extends PluginBase {
    /*** @var ChorusMain|null */
    private static $instance;

    public function onEnable() {
        self::$instance = $this;
        BlockFactory::registerBlock(new ChorusFlower(Block::CHORUS_FLOWER, 0, "Chorus Flower", Item::CHORUS_FLOWER));
        BlockFactory::registerBlock(new ChorusPlant(Block::CHORUS_PLANT, 0, "Chorus Plant", Item::CHORUS_PLANT));
    }

    public static function getInstance(): ?ChorusMain {
        return self::$instance;
    }
}