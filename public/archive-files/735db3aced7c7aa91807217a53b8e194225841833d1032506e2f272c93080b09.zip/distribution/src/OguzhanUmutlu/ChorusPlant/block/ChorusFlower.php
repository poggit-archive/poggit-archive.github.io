<?php

namespace OguzhanUmutlu\ChorusPlant\block;

use Exception;
use pocketmine\block\Block;
use pocketmine\block\BlockFactory;
use pocketmine\block\BlockToolType;
use pocketmine\block\Flowable;
use pocketmine\event\block\BlockGrowEvent;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\Player;

class ChorusFlower extends Flowable {

    protected $id = Block::CHORUS_FLOWER;

    public function getName() : string{
        return "Chorus Flower";
    }

    public function getHardness(): float {
        return 0.4;
    }

    public function getToolType(): int {
        return BlockToolType::TYPE_AXE;
    }

    public function isTransparent(): bool {
        return true;
    }

    public function isFlammable(): bool {
        return false;
    }

    public function getBlastResistance(): float {
        return 0.4;
    }

    public function onNearbyBlockChange() : void{
        $center = $this->getCenterBlock();
        if(!$center){
            $this->getLevelNonNull()->useBreakOn($this);
        }
    }

    public function ticksRandomly() : bool{
        return true;
    }

    /*** @throws Exception */
    public function onRandomTick() : void{
        if($this->getSide(Vector3::SIDE_DOWN)->getId() !== self::CHORUS_PLANT){
            if($this->meta === 15){
                $x = random_int(0, 1);
                $y = random_int(0, 1);
                $z = $x == 0 ? random_int(0, 1) : 0;
                $b = $this->getLevelNonNull()->getBlockAt($this->x + $x, $this->y + $y, $this->z + $z);
                $this->meta = 0;
                $this->getLevelNonNull()->setBlock($this, Block::get(Block::CHORUS_PLANT), true);
                if($b->getId() === self::AIR){
                    $ev = new BlockGrowEvent($b, BlockFactory::get(Block::CHORUS_PLANT));
                    $ev->call();
                    if($ev->isCancelled()){
                        return;
                    }
                    $this->getLevelNonNull()->setBlock($b, $ev->getNewState(), true);
                    return;
                }
            }else{
                ++$this->meta;
                $this->getLevelNonNull()->setBlock($this, $this, true);
            }
        }
    }

    public function place(Item $item, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, Player $player = null) : bool{
        $sides = array_map(function($n){return $this->getSide($n);}, [0, 2, 3, 4, 5]);
        if(empty(array_filter($sides,function($n){return $n->getId() === self::CHORUS_PLANT;}))) return false;
        if($this->getCenterBlock()){
            $this->getLevelNonNull()->setBlock($blockReplace, BlockFactory::get($this->getId()), true);
            return true;
        }
        return false;
    }

    public function hasSide(): bool {
        $sides = array_map(function($n){return $this->getSide($n);}, [0, 1, 2, 3, 4, 5]);
        return !empty(array_filter($sides,function($n){return $n->getId() === self::CHORUS_PLANT;}));
    }

    public function getCenterBlock(int $loop = 0): ?Block {
        if($loop > 32) return null;
        if(!$this->hasSide() && $this->getSide(self::SIDE_DOWN)->getId() != Block::END_STONE)
            return null;
        $down = $this->getSide(self::SIDE_DOWN);
        if($down->getId() == Block::END_STONE)
            return $this;
        if($down instanceof ChorusFlower)
            return $down->getCenterBlock($loop+1);
        $north = $this->getSide(self::SIDE_NORTH);
        $south = $this->getSide(self::SIDE_SOUTH);
        $west = $this->getSide(self::SIDE_WEST);
        $east = $this->getSide(self::SIDE_EAST);
        if($north instanceof ChorusFlower && !$this->getSide(self::SIDE_SOUTH, 2) instanceof ChorusFlower)
            return $north->getCenterBlock($loop+1);
        if($south instanceof ChorusFlower)
            return $south->getCenterBlock($loop+1);
        if($west instanceof ChorusFlower && !$this->getSide(self::SIDE_EAST, 2) instanceof ChorusFlower)
            return $west->getCenterBlock($loop+1);
        if($east instanceof ChorusFlower)
            return $east->getCenterBlock($loop+1);
        $up = $this->getSide(self::SIDE_UP);
        if($up instanceof ChorusFlower)
            return $up->getCenterBlock($loop+1);
        return $this->getCenterBlock($loop+1);
    }
}