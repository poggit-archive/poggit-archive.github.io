<?php

namespace OguzhanUmutlu\ChorusPlant\block;

use pocketmine\block\Block;
use pocketmine\item\Item;

class ChorusPlant extends ChorusFlower {

    protected $id = Block::CHORUS_PLANT;

    public function getName() : string{
        return "Chorus Plant";
    }

    public function onRandomTick() : void{}

    public function getDrops(Item $item): array {
        return [Item::get(Item::CHORUS_FRUIT)];
    }
}