<?php

namespace skillDev5235\PlotRating;

// PLUGIN BY skillPhil5235 (skillDev5235)

use pocketmine\block\Air;
use pocketmine\block\Block;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\SignChangeEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\item\Item;
use pocketmine\item\Sign;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\math\Vector3;

class Rating extends PluginBase implements Listener
{
    public static $prefix;

    public function onEnable()
    {
        // $this->getLogger()->info("§aEnabled | Version 1.0 by skillPhil/Dev5235");

        @mkdir($this->getDataFolder());
        $this->saveResource("config.yml");

        Rating::$prefix = $this->getConfig()->get("prefix");

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onDisable()
    {
        // $this->getLogger()->info("§cDisabled | Version 1.0 by skillPhil/Dev5235");
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
    {
        if ($command->getName() == "rating") {
            if ($sender instanceof Player) {
                if ($sender->hasPermission("plotrating.rating")) {
                    if (empty($args[0])) {
                        $sender->sendMessage(self::$prefix . $this->getConfig()->get("no-args-given-error"));
                    } else {
                        if ($args[0] == "help") {
                            $sender->sendMessage(self::$prefix . " §eHelp");
                            $sender->sendMessage($this->getConfig()->get("help-line-1"));
                        } else {
                            $sender->sendMessage(self::$prefix . $this->getConfig()->get("subcommand-not-found-error"));
                        }
                    }
                } else {
                    $sender->sendMessage(self::$prefix . $this->getConfig()->get("no-permission-error"));
                }
            } else {
                $sender->sendMessage(self::$prefix . $this->getConfig()->get("console-run-error"));
            }
        }
        return true;
    }

    public function onRating(SignChangeEvent $event)
    {

        $name = $event->getPlayer()->getName();

        if($event->getPlayer()->hasPermission("plotrating.create")) {
            if ($event->getLine(0) == $this->getConfig()->get("line-1")) {
                $event->setLine(0, $this->getConfig()->get("line-1-replace"));
                if (!empty($event->getLine(1))) {
                    $lines = array($event->getLine(1));
                    $result = $event->getLine(1);
                    $name = $event->getPlayer()->getName();
                    $text = implode("\n", $lines);
                    $results = $text;
                    $event->setLine(1, $results . " Stars");
                    $event->setLine(2, "§bFrom: §7$name");
                    $event->getPlayer()->sendMessage(self::$prefix . $this->getConfig()->get("create-succes-message"));
                    foreach ($this->getServer()->getOnlinePlayers() as $onlinePlayer) {
                        $onlinePlayer->sendMessage(self::$prefix . $this->getConfig()->get("allplayers-message"));
                    }
                } else {
                    $event->getPlayer()->sendMessage(self::$prefix . $this->getConfig()->get("error-line2-empty"));
                }
            }
        } else {
            $event->getPlayer()->sendMessage(self::$prefix . $this->getConfig()->get("no-sign-create-perms"));
        }
    }
}
