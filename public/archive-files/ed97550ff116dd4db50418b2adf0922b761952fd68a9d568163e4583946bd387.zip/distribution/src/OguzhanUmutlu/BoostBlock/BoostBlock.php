<?php

namespace OguzhanUmutlu\BoostBlock;

use pocketmine\level\particle\Particle;
use pocketmine\level\Position;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;

class BoostBlock extends PluginBase {
    /*** @var BoostBlock */
    private static $instance;
    /*** @var Player[] */
    private $motion = [];
    /*** @var Player */
    public static $addBlock = [];
    private static $particles = [];
    public function onEnable() {
        self::$instance = $this;
        $this->saveDefaultConfig();
        $this->getServer()->getPluginManager()->registerEvents(new EventListener(), $this);
        if($this->getConfig()->get("command-enabled"))
            $this->getServer()->getCommandMap()->register($this->getName(), new BoostBlockCommand());
    }

    public static function arrayToPosition(array $position): Position {
        return new Position(
            $position["x"] ?? 0,
            $position["y"] ?? 0,
            $position["z"] ?? 0,
            self::$instance->getServer()->getLevelByName($position["level"] ?? "")
        );
    }

    public static function positionToArray(Position $position): array {
        return [
            "x" => $position->x,
            "y" => $position->y,
            "z" => $position->z,
            "level" => $position->level ? $position->level->getName() : null
        ];
    }

    public static function getBoostingPlayers(): array {
        return self::$instance->motion;
    }

    public static function setBoostingPlayer(Player $player): bool {
        if(isset(self::$instance->motion[$player->getName()])) return false;
        if(($player->getGamemode() != 2 && $player->getGamemode() != 1) || $player->isFlying() || $player->isOnGround() || $player->isUnderwater())
            return false;
        self::$instance->motion[$player->getName()] = $player;
        return true;
    }

    public static function unsetBoostingPlayer(Player $player): bool {
        if(!isset(self::$instance->motion[$player->getName()])) return false;
        unset(self::$instance->motion[$player->getName()]);
        return true;
    }

    public static function checkBoosting(Player $player) {
        if(!isset(self::$instance->motion[$player->getName()])) return;
        if(($player->getGamemode() != 2 && $player->getGamemode() != 1) || $player->isFlying() || $player->isOnGround() || $player->isUnderwater()) {
            self::unsetBoostingPlayer($player);
        }
    }

    public static function isBoostingPlayer(Player $player): bool {
        return isset(self::$instance->motion[$player->getName()]);
    }

    public static function setBoostParticle(Player $player, Particle $particle) {
        self::$particles[$player->getName()] = $particle;
    }

    public static function getBoostParticle(Player $player) {
        return self::$particles[$player->getName()] ?? null;
    }

    public static function unsetBoostParticle(Player $player) {
        if(isset(self::$particles[$player->getName()]))
            unset(self::$particles[$player->getName()]);
    }

    public static function getInstance(): BoostBlock {
        return self::$instance;
    }
}