<?php

namespace OguzhanUmutlu\BoostBlock;

use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerMoveEvent;

class EventListener implements Listener {
    public function onMove(PlayerMoveEvent $e) {
        $player = $e->getPlayer();
        BoostBlock::checkBoosting($player);
        if(BoostBlock::isBoostingPlayer($player)) {
            if(BoostBlock::getBoostParticle($player)) {
                $p = get_class(BoostBlock::getBoostParticle($player));
                $p = new $p($player);
                $player->getLevelNonNull()->addParticle($p);
            }
        }
        $pos = BoostBlock::positionToArray($player);
        $block = $player->getLevelNonNull()->getBlock($player->add(0, -1));
        $positions = BoostBlock::getInstance()->getConfig()->getNested("positions");
        $blocks = BoostBlock::getInstance()->getConfig()->getNested("blocks");
        $motion = $player->getMotion()->add($player->getDirectionVector()->multiply(BoostBlock::getInstance()->getConfig()->getNested("boost")));
        if(!BoostBlock::getInstance()->getConfig()->getNested("up-down-enabled")) {
            $y = -sin(deg2rad(0));
            $xz = cos(deg2rad(0));
            $x = -$xz * sin(deg2rad($player->yaw));
            $z = $xz * cos(deg2rad($player->yaw));
            $direction = $player->temporalVector->setComponents($x, $y, $z)->normalize();
            $motion = $player->getMotion()->add($direction->multiply(BoostBlock::getInstance()->getConfig()->getNested("boost")))->add(0, BoostBlock::getInstance()->getConfig()->getNested("up-increaser")-BoostBlock::getInstance()->getConfig()->getNested("down-increaser"));
        }
        if(in_array($pos, $positions) || in_array($block->getId().":".$block->getDamage(), $blocks)) {
            BoostBlock::setBoostingPlayer($player);
            $player->setMotion($motion);
        }
    }

    public function onChat(PlayerChatEvent $e) {
        $player = $e->getPlayer();
        if($e->getMessage() == "\$cancel" && isset(BoostBlock::$addBlock[$player->getName()])) {
            unset(BoostBlock::$addBlock[$player->getName()]);
            $e->setCancelled();
            $player->sendMessage("§c> Action cancelled.");
        }
    }

    public function onBreak(BlockBreakEvent $e) {
        $player = $e->getPlayer();
        if(isset(BoostBlock::$addBlock[$player->getName()])) {
            unset(BoostBlock::$addBlock[$player->getName()]);
            $e->setCancelled();
            $blocks = BoostBlock::getInstance()->getConfig()->getNested("blocks");
            if(in_array($e->getBlock()->getId().":".$e->getBlock()->getDamage(), $blocks)) {
                $player->sendMessage("§c> This block is already added!");
                return;
            }
            $blocks[] = $e->getBlock()->getId().":".$e->getBlock()->getDamage();
            BoostBlock::getInstance()->getConfig()->setNested("blocks", $blocks);
            BoostBlock::getInstance()->getConfig()->save();
            BoostBlock::getInstance()->getConfig()->reload();
            $player->sendMessage("§a> Boost block successfully added!.");
        }
    }
}