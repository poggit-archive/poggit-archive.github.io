<?php

namespace OguzhanUmutlu\BoostBlock;

use pocketmine\command\Command;
use pocketmine\command\PluginIdentifiableCommand;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class BoostBlockCommand extends Command implements PluginIdentifiableCommand {
    public function __construct() {
        parent::__construct("boostblock", "Manage boost blocks!");
        $this->setPermission("boostblock.cmd");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {
        switch($args[0] ?? "") {
            case "blocks":
                switch($args[1] ?? "") {
                    case "add":
                        BoostBlock::$addBlock[$sender->getName()] = $sender;
                        $sender->sendMessage("§a> Break the boost block to add! To cancel action type \$cancel to chat.");
                        break;
                    case "remove":
                        if(!isset($args[2])) {
                            $sender->sendMessage("§c> Usage: /boostblock blocks remove <id>");
                            return;
                        }
                        $blocks = BoostBlock::getInstance()->getConfig()->getNested("blocks");
                        if(!isset($blocks[$args[2]])) {
                            $sender->sendMessage("§c> Boost block not found.");
                            return;
                        }
                        unset($blocks[$args[2]]);
                        BoostBlock::getInstance()->getConfig()->setNested("blocks", $blocks);
                        BoostBlock::getInstance()->getConfig()->save();
                        BoostBlock::getInstance()->getConfig()->reload();
                        $sender->sendMessage("§a> Boost block has been removed!");
                        break;
                    case "list":
                        $sender->sendMessage("§e> Added boost blocks:");
                        foreach(BoostBlock::getInstance()->getConfig()->getNested("blocks") as $id => $block) {
                            $sender->sendMessage("§a> ID: ".$id.", Block: ".$block);
                        }
                        break;
                    default:
                        $sender->sendMessage("§c> Usage: /boostblock blocks <add, remove, list>");
                }
                break;
            case "positions":
                switch($args[1] ?? "") {
                    case "add":
                        if(!$sender instanceof Player) {
                            $sender->sendMessage("§c> Use this command in-game.");
                            return;
                        }
                        $positions = BoostBlock::getInstance()->getConfig()->getNested("positions");
                        if(in_array(BoostBlock::positionToArray($sender), $positions)) {
                            $sender->sendMessage("§c> This position is already added!");
                            return;
                        }
                        $positions[] = BoostBlock::positionToArray($sender);
                        BoostBlock::getInstance()->getConfig()->setNested("positions", $positions);
                        BoostBlock::getInstance()->getConfig()->save();
                        BoostBlock::getInstance()->getConfig()->reload();
                        $sender->sendMessage("§a> Boost position added to your position.");
                        break;
                    case "remove":
                        if(!isset($args[2])) {
                            $sender->sendMessage("§c> Usage: /boostblock positions remove <id>");
                            return;
                        }
                        $positions = BoostBlock::getInstance()->getConfig()->getNested("positions");
                        if(!isset($positions[$args[2]])) {
                            $sender->sendMessage("§c> Boost position not found.");
                            return;
                        }
                        unset($positions[$args[2]]);
                        BoostBlock::getInstance()->getConfig()->setNested("positions", $positions);
                        BoostBlock::getInstance()->getConfig()->save();
                        BoostBlock::getInstance()->getConfig()->reload();
                        $sender->sendMessage("§a> Boost position has been removed!");
                        break;
                    case "list":
                        $sender->sendMessage("§e> Added boost positions:");
                        foreach(BoostBlock::getInstance()->getConfig()->getNested("positions") as $id => $position) {
                            $sender->sendMessage("§a> ID: ".$id.", X: ".$position["x"].", Y: ".$position["y"].", Z: ".$position["z"].", Level: ".$position["level"]);
                        }
                        break;
                    default:
                        $sender->sendMessage("§c> Usage: /boostblock positions <add, remove, list>");
                }
                break;
            default:
                $sender->sendMessage("§c> Usage: /boostblock <blocks, positions>");
        }
    }
    
    public function getPlugin(): \pocketmine\plugin\Plugin {
        return BoostBlock::getInstance();
    }
}
