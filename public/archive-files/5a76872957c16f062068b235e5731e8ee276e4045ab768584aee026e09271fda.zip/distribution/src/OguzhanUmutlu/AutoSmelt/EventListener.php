<?php

namespace OguzhanUmutlu\AutoSmelt;

use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Listener;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\Item;

class EventListener implements Listener {
    public function onBreak(BlockBreakEvent $event) {
        if(!$event->getPlayer()->hasPermission("auto"."smelt.perm")) return;
        if($event->getItem()->hasEnchantment(Enchantment::SILK_TOUCH)) return;
        $ores = [
            Item::COAL_ORE => Item::get(Item::COAL),
            Item::IRON_ORE => Item::get(Item::IRON_INGOT),
            Item::GOLD_ORE => Item::get(Item::GOLD_INGOT),
            Item::LAPIS_ORE => Item::get(Item::DYE, 4),
            Item::REDSTONE_ORE => Item::get(Item::REDSTONE),
            Item::LIT_REDSTONE_ORE => Item::get(Item::REDSTONE),
            Item::DIAMOND_ORE => Item::get(Item::DIAMOND),
            Item::EMERALD_ORE => Item::get(Item::EMERALD),
            Item::QUARTZ_ORE => Item::get(Item::QUARTZ)
        ];
        $event->setDrops(array_map(function ($item) use ($ores) {
            return in_array($item->getId(), array_keys($ores)) ? $ores[$item->getId()] : $item;
        }, $event->getDrops()));
    }
}