<?php

namespace OguzhanUmutlu\AutoSmelt;

use pocketmine\plugin\PluginBase;

class AutoSmelt extends PluginBase {
    public function onEnable() {
        $this->getServer()->getPluginManager()->registerEvents(new EventListener(), $this);
    }
}