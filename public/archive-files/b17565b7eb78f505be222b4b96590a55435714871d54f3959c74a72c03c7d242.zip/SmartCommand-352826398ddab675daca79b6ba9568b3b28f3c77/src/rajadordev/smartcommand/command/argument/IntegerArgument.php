<?php

declare (strict_types=1);

/***
 *   
 * Rajador Developer
 * 
 * ▒█▀▀█ ░█▀▀█ ░░░▒█ ░█▀▀█ ▒█▀▀▄ ▒█▀▀▀█ ▒█▀▀█ 
 * ▒█▄▄▀ ▒█▄▄█ ░▄░▒█ ▒█▄▄█ ▒█░▒█ ▒█░░▒█ ▒█▄▄▀ 
 * ▒█░▒█ ▒█░▒█ ▒█▄▄█ ▒█░▒█ ▒█▄▄▀ ▒█▄▄▄█ ▒█░▒█
 * 
 * GitHub: https://github.com/rajadordev
 * 
 * Discord: rajadortv
 * 
 * 
**/

namespace rajadordev\smartcommand\command\argument;

class IntegerArgument extends BaseArgument
{

    public function __construct(string $name, bool $required = true)
    {
        parent::__construct($name, 'interger', $required);
    }

    public function parse(string &$given) : bool 
    {
        if (is_numeric($given))
        {
            if (strpos($given, '.') === false)
            {
                $given = (int) $given;
                return true;
            }
        }
        return false;
    }
    
}