<?php

declare (strict_types=1);

/***
 *   
 * Rajador Developer
 * 
 * ▒█▀▀█ ░█▀▀█ ░░░▒█ ░█▀▀█ ▒█▀▀▄ ▒█▀▀▀█ ▒█▀▀█ 
 * ▒█▄▄▀ ▒█▄▄█ ░▄░▒█ ▒█▄▄█ ▒█░▒█ ▒█░░▒█ ▒█▄▄▀ 
 * ▒█░▒█ ▒█░▒█ ▒█▄▄█ ▒█░▒█ ▒█▄▄▀ ▒█▄▄▄█ ▒█░▒█
 * 
 * GitHub: https://github.com/rajadordev
 * 
 * Discord: rajadortv
 * 
 * 
**/

namespace rajadordev\smartcommand\command\argument;

/**
 * This argument should be used when you will accept float and integers
 */
class NumberArgument extends BaseArgument
{

    public function __construct(string $name, bool $required = true)
    {
        parent::__construct($name, 'number', $required);
    }

    public function parse(string &$given) : bool 
    {
        if (is_numeric($given))
        {
            if (strpos($given, '.') !== false) 
            {
                $given = (float) $given;
            } else {
                $given = (int) $given;
            }
            return true;
        }
        return false;
    }

}