<?php

/**
  *  A free library for PocketMine-MP.
  *	
  *	Copyright (c) AEDXDEV
  *  
  *	Youtube: AEDX DEV 
  *	Discord: aedxdev
  *	Github: AEDXDEV
  *	Email: aedxdev@gmail.com
  *	Donate: https://paypal.me/AEDXDEV
  *   
  *        This program is free software: you can redistribute it and/or modify
  *        it under the terms of the GNU General Public License as published by
  *        the Free Software Foundation, either version 3 of the License, or
  *        (at your option) any later version.
  *
  *        This program is distributed in the hope that it will be useful,
  *        but WITHOUT ANY WARRANTY; without even the implied warranty of
  *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *        GNU General Public License for more details.
  *
  *        You should have received a copy of the GNU General Public License
  *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *   
  */

declare(strict_types=1);

namespace AEDXDEV\ECMD\args;

use pocketmine\command\CommandSender;
use pocketmine\math\Vector3;
use function preg_match;

class BlockPositionArgument extends Vector3Argument{

	public function isValidCoordinate(string $coordinate, bool $locatable): bool{
  	$number = "(?:" . ($locatable ? "(?:~-|~\+)?" : "") . "-?\d+)";
  	$pattern = $locatable ? "/^(?:{$number}|~)$/" : "/^{$number}$/";
  	return (bool)preg_match($pattern, $coordinate);
  }

	public function parse(string $argument, CommandSender $sender): Vector3{
		$v = parent::parse($argument, $sender);
		return $v->floor();
	}
}