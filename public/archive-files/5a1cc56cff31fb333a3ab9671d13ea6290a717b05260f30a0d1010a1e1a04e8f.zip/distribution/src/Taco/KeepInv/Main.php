<?php
/*             _             _____                 
     /\       | |           |  __ \                
    /  \   ___| |_ _ __ __ _| |  | | _____   _____ 
   / /\ \ / __| __| '__/ _` | |  | |/ _ \ \ / / __|
  / ____ \\__ \ |_| | | (_| | |__| |  __/\ V /\__ \
 /_/    \_\___/\__|_|  \__,_|_____/ \___| \_/ |___/
                                                   
                                                   
Copyright (C) 2020  TWRRR (github.com/twrrr)
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

namespace Taco\KeepInv;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\utils\Config;

class Main extends PluginBase implements Listener {
    public function Death(PlayerDeathEvent $event) {
        if ($this->getConfig()->get("KeepInventory") == true) {
            $event->setKeepInventory(true);
        }
        elseif ($this->getConfig()->get("KeepInventory") == false) {
            $event->setKeepInventory(false);
        }
    }
}
