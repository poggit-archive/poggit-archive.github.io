---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:


**Expected behavior**
A clear and concise description of what you expected to happen.
**FormsUI Library information**


**Screenshots**
If applicable, add screenshots to help explain your problem.


**Crashdump or other files related to the problem**

**Additional context**
Add any other context about the problem here.
