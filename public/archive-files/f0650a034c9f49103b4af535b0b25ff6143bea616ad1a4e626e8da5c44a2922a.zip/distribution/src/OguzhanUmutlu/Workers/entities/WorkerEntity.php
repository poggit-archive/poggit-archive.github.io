<?php

namespace OguzhanUmutlu\Workers\entities;

use OguzhanUmutlu\Workers\inventory\WorkerInventory;
use OguzhanUmutlu\Workers\Workers;
use pocketmine\block\Block;
use pocketmine\block\Slab;
use pocketmine\block\Solid;
use pocketmine\block\Stair;
use pocketmine\block\Wood;
use pocketmine\block\Wood2;
use pocketmine\entity\Living;
use pocketmine\entity\object\ItemEntity;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\inventory\InventoryPickupItemEvent;
use pocketmine\item\Item;
use pocketmine\item\TieredTool;
use pocketmine\level\Level;
use pocketmine\math\AxisAlignedBB;
use pocketmine\math\Vector3;
use pocketmine\math\VoxelRayTrace;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\network\mcpe\protocol\AddActorPacket;
use pocketmine\network\mcpe\protocol\LevelEventPacket;
use pocketmine\network\mcpe\protocol\TakeItemActorPacket;
use pocketmine\Player;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\utils\Binary;

class WorkerEntity extends Living {
    public const TYPE_MINER = 0;
    public const TYPE_ITEM_GRABBER = 1;
    public const TYPE_LUMBERJACK = 2;
    public const NETWORK_ID = 115;
    public $type = -1;
    public $owner = "";
    /**
     * @var Block|null
     */
    public $isBreaking = null;
    public $width = 0.6;
    public $height = 1.8;
    public $eyeHeight = 0.4;
    public $moveFood = 0;
    /*** @var WorkerInventory */
    public $inventory;
    /*** @return WorkerInventory */
    public function getInventory(): WorkerInventory {
        return $this->inventory;
    }

    protected function initEntity(): void {
        if(!$this->namedtag->hasTag("workerType") || !$this->namedtag->hasTag("workerOwner")) {
            parent::initEntity();
            $this->close();
            return;
        }
        $this->type = $this->namedtag->getInt("workerType");
        $this->owner = $this->namedtag->getString("workerOwner");
        if(!$this->namedtag->hasTag("disallowedItems"))
            $this->namedtag->setIntArray(
                "disallowedItems",
                []
            );
        $this->setFood($this->namedtag->getFloat("workerFood", 100));
        $this->setScale(0.7);
        $this->setMaxHealth(100);
        $this->setHealth($this->namedtag->getFloat("Health", 100));
        $this->refreshNameTag();
        $this->setNameTagAlwaysVisible();
        $this->setNameTagVisible();
        parent::initEntity();
        $this->inventory = new WorkerInventory($this);
        if($this->namedtag->hasTag("WorkerInventory")) {
            $tag = $this->namedtag->getListTag("WorkerInventory");
            foreach($tag->getValue() as $compound) {
                if($compound instanceof CompoundTag) {
                    $item = Item::nbtDeserialize($compound);
                    $slot = $compound->getInt("ItemSlot");
                    $this->getInventory()->setItem($slot, $item);
                }
            }
        }
    }
    public function getOwner(): ?Player {
        return Server::getInstance()->getPlayerExact($this->owner);
    }
    public $lastFloorAge = null;
    public $isWooding = false;
    public function onUpdate(int $currentTick): bool {
        if(!$this->level)
            $this->close();
        if($this->closed) return false;
        $this->setAge($this->getAge()+0.000001);
        if(!$this->lastFloorAge || $this->lastFloorAge < floor($this->getAge())) {
            $this->lastFloorAge = floor($this->getAge());
            $this->setScale(0.7+($this->getAge()/20) > 0.8 ? 0.8 : 0.7+($this->getAge()/20));
        }
        if(!$this->canBreathe())
            $this->setMotion(new Vector3(0.2, 0.3, 0.2));
        switch($this->type) {
            case self::TYPE_MINER:
                if(!$this->getOwner())
                    break;
                if($this->isBreaking) {
                    if($this->isBreaking->level) {
                        $this->lookAt($this->isBreaking);
                        if($this->isBreaking->distance($this) > 4.5 || !$this->isOreOrStone($this->isBreaking->level->getBlock($this->isBreaking))) {
                            $this->level->broadcastLevelEvent($this->isBreaking, LevelEventPacket::EVENT_BLOCK_STOP_BREAK);
                            $this->isBreaking = null;
                        }
                    }
                    break;
                } else $this->pitch = 0;
                $dx = null;
                $dy = null;
                $dz = null;
                for ($x = -1; $x <= 1; $x++)
                    for ($z = -1; $z <= 1; $z++)
                        for ($y = 0; $y <= 1; $y++)
                            if(is_null($dx) && $this->isOreOrStone($this->level->getBlock($this->add($x, $y, $z)))) {
                                $dx = $x;
                                $dy = $y;
                                $dz = $z;
                            }
                if(!is_null($dx) && !is_null($dy) && !is_null($dz)) {
                    if($this->getFood() <= 5) break;
                    $block = $this->level->getBlock($this->add($dx, $dy, $dz));
                    $this->lookAt($block);
                    $this->level->broadcastLevelEvent($block, LevelEventPacket::EVENT_BLOCK_START_BREAK, (int)(3900/$block->getBreakTime($this->getInventory()->getItem(0))));
                    $this->isBreaking = $block;
                    Workers::$instance->getScheduler()->scheduleDelayedTask(new class($this, $block) extends Task {
                        public $block;
                        public $player;
                        public function __construct(WorkerEntity $player, Block $block){$this->block = $block;$this->player = $player;}
                        public function onRun(int $currentTick) {
                            if(!$this->player->isBreaking || $this->player->isClosed() || !$this->player->getOwner() || $this->player->getOwner()->isClosed() || $this->player->getFood() <= 5 || !$this->block->level || !$this->player->isOreOrStone($this->block->level->getBlock($this->block)) || $this->player->level->getId() != $this->block->level->getId()) {
                                $this->player->isBreaking = null;
                                return;
                            }
                            if(!$this->player->isBreaking->equals($this->block))
                                return;
                            $it = $this->player->getInventory()->getItem(0);
                            $this->player->isBreaking = null;
                            $ev = new BlockBreakEvent($this->player->getOwner(), $this->block, $it);
                            $ev->call();
                            if(!$ev->isCancelled()) {
                                $this->player->break($this->block, $it);
                                $this->player->getInventory()->setItem(0, $it);
                            }
                        }
                    }, $block->getBreakTime($this->getInventory()->getItem(0))*20);
                }
                break;
            case self::TYPE_ITEM_GRABBER:
                if(!$this->getOwner() instanceof Player || !$this->level instanceof Level || !$this->boundingBox instanceof AxisAlignedBB)
                    break;
                foreach($this->level->getEntities() as $entity) {
                    if($entity->distance($this) < 7 && $entity instanceof ItemEntity && !in_array($entity->getItem()->getId(), $this->namedtag->getIntArray("disallowedItems", [])) && $this->getInventory()->canAddItem($entity->getItem())) {
                        $ev = new InventoryPickupItemEvent($this->getInventory(), $entity);
                        $ev->call();
                        if(!$ev->isCancelled()) {
                            $pk = new TakeItemActorPacket();
                            $pk->eid = $this->getId();
                            $pk->target = $entity->getId();
                            $this->server->broadcastPacket($entity->getViewers(), $pk);
                            $this->getInventory()->addItem(clone $entity->getItem());
                            $entity->flagForDespawn();
                        }
                    }
                }
                break;
            case self::TYPE_LUMBERJACK:
                if(!$this->getOwner() instanceof Player || !$this->level instanceof Level || !$this->boundingBox instanceof AxisAlignedBB)
                    break;
                if($this->isBreaking) {
                    if($this->isBreaking->level) {
                        $this->lookAt($this->isBreaking);
                        if($this->isBreaking->distance($this) > 4.5 || (!$this->isBreaking instanceof Wood && !$this->isBreaking instanceof Wood2)) {
                            $this->level->broadcastLevelEvent($this->isBreaking, LevelEventPacket::EVENT_BLOCK_STOP_BREAK);
                            $this->isBreaking = null;
                        }
                    }
                } else $this->pitch = 0;
                foreach($this->level->getEntities() as $entity) {
                    if($entity->distance($this) < 2 && $entity instanceof ItemEntity && $entity->getItem()->getId() == Item::SAPLING && $this->getInventory()->canAddItem($entity->getItem())) {
                        $ev = new InventoryPickupItemEvent($this->getInventory(), $entity);
                        $ev->call();
                        if(!$ev->isCancelled()) {
                            $pk = new TakeItemActorPacket();
                            $pk->eid = $this->getId();
                            $pk->target = $entity->getId();
                            $this->server->broadcastPacket($entity->getViewers(), $pk);
                            $this->getInventory()->addItem(clone $entity->getItem());
                            $entity->flagForDespawn();
                        }
                    }
                }
                if($this->getFood() <= 5) break;
                if(empty($this->woods) || !$this->isBreaking)
                    $this->isWooding = false;
                if($this->isWooding) break;
                $blocks = $this->level->getCollisionBlocks($this->boundingBox->expandedCopy(2, 2, 2));
                $blocks = array_filter($blocks, function($block){
                    return ($block instanceof Wood || $block instanceof Wood2) && $block->getFloorY() == $this->getFloorY();
                });
                if(empty($blocks))
                    break;
                $this->woods = $blocks;
                $this->goAndWood();
                break;
        }
        return parent::onUpdate($currentTick);
    }
    public function isOreOrStone(Block $block): bool {
        return in_array($block->getId(), [Block::STONE, Block::COBBLESTONE, Block::COAL_ORE, Block::IRON_ORE, Block::GOLD_ORE, Block::LAPIS_ORE, Block::DIAMOND_ORE, Block::EMERALD_ORE, Block::LIT_REDSTONE_ORE, Block::QUARTZ_ORE, Block::REDSTONE_ORE]);
    }
    public function getName(): string {
        return "Worker";
    }
    public function attack(EntityDamageEvent $source): void {
        if($source instanceof EntityDamageByEntityEvent)
            $source->setBaseDamage(0.00000000000001);
        $back = $this->getHealth();
        parent::attack($source);
        if($source instanceof EntityDamageByEntityEvent)
            $this->setHealth($back);
    }
    public function getMaxFood(): int {
        return 100;
    }
    public function setHealth(float $amount): void {
        parent::setHealth($amount);
        $this->namedtag->setFloat("Health", $amount);
        $this->refreshNameTag();
    }
    public function refreshNameTag(): void {
        $handItem = $this->inventory ? $this->inventory->getItem(0) : Item::get(0);
        $this->setNameTag("§e".$this->owner."'s ".[
                self::TYPE_MINER => "Miner",
                self::TYPE_ITEM_GRABBER => "Item Grabber",
                self::TYPE_LUMBERJACK => "Lumberjack"
            ][$this->type]." Worker\n§6Health: §a".$this->getHealth()."/".$this->getMaxHealth()."\n§6Food: §a".$this->getFood()."/".$this->getMaxFood().($handItem instanceof TieredTool ? "\n§6Tool: §a%".(100-round(($handItem->getDamage()/$handItem->getMaxDurability())*100, 1)) : "")."\n".$this->message);
    }
    public $message = "";
    public function sendMessage(string $message) {
        if(strlen($this->message) > 0) return;
        $this->message = $message;
        $this->refreshNameTag();
        Workers::$instance->getScheduler()->scheduleDelayedTask(new class($this) extends Task {
            public $th;
            public function __construct(WorkerEntity $entity) {
                $this->th = $entity;
            }
            public function onRun(int $currentTick) {
                $this->th->message = "";
                $this->th->refreshNameTag();
            }
        }, 20);
    }
    public function move(float $dx, float $dy, float $dz): void {
        $block = $this->level->getBlock(new Vector3($this->x+$dx, $this->y+$dy, $this->z+$dz));
        if($block instanceof Slab || $block instanceof Stair)
            if($dy == 0)
                $dy++;
        $this->addMoveFood($dx/5);
        $this->addMoveFood($dy/5);
        $this->addMoveFood($dz/5);
        parent::move($dx, $dy, $dz);
    }
    public function break(Block $block, Item &$item) {
        $block->level->useBreakOn($block, $item, null, true);
        $this->addMoveFood(0.3);
    }
    public function addMoveFood(float $mf) {
        $this->moveFood+=abs($mf);
        if($this->moveFood >= 5) {
            $this->moveFood-=5;
            $this->setFood($this->getFood()-1);
        }
    }
    public function kill(): void {
        if(!$this->inventory) {
            $this->inventory = new WorkerInventory($this);
            if ($this->namedtag->hasTag("WorkerInventory")) {
                foreach ($this->namedtag->getListTag("WorkerInventory") as $item) {
                    if ($item instanceof CompoundTag) {
                        $slot = $item->getInt("Slot");
                        $item->removeTag("Slot");
                        $this->inventory->setItem($slot, Item::nbtDeserialize($item));
                    }
                }
            } else $this->inventory->saveInventory();
        }
        if($this->level)
            foreach($this->inventory->getContents() as $item)
                $this->level->dropItem($this, $item);
        parent::kill();
    }
    public function getFood(): float {
        return $this->namedtag->getFloat("workerFood", 100);
    }
    public function setFood(float $food): void {
        $this->namedtag->setFloat("workerFood", $food);
        $this->refreshNameTag();
        $this->saveNBT();
    }
    public function getAge(): float {
        return $this->namedtag->getFloat("workerAge", 1);
    }
    public function setAge(float $age): void {
        $this->namedtag->setFloat("workerAge", $age);
        $this->saveNBT();
    }
    public function getEyeHeight(): float {
        $this->eyeHeight = $this->getScale();
        return $this->getScale();
    }
    /*** @param Block[] $woods */
    public $woods = [];
    public function goAndWood() {
        $woods = $this->woods;
        $woods = array_filter($woods, function($block){
            return ($block instanceof Wood || $block instanceof Wood2) && $block->y == $this->getFloorY();
        });
        $woods = array_slice($woods, 0, 10);
        /** @var Block[] $woods */
        $woods = array_values($woods);
        $woods = array_slice($woods, 0, 10);
        if(empty($woods)) {
            $this->isWooding = false;
            return;
        }
        $this->isWooding = true;
        $wood = $woods[0];
        if($wood->distance($this) <= 2.5) {
            if($this->getFood() <= 5) {
                $this->isWooding = false;
                return;
            }
            $block = $this->level->getBlock($wood);
            $this->lookAt($block);
            $this->level->broadcastLevelEvent($block, LevelEventPacket::EVENT_BLOCK_START_BREAK, (int)(3900/$block->getBreakTime($this->getInventory()->getItem(0))));
            $this->isBreaking = $block;
            Workers::$instance->getScheduler()->scheduleDelayedTask(new class($this, $block, $woods) extends Task {
                public $block;
                public $player;
                public $woods = [];
                public function __construct(WorkerEntity $player, Block $block, array $woods){
                    $this->block = $block;$this->player = $player;$this->woods = $woods;}
                public function onRun(int $currentTick) {
                    if(!$this->player->isBreaking || $this->player->isClosed() || !$this->player->getOwner() || $this->player->getOwner()->isClosed() || $this->player->getFood() <= 5 || !$this->block->level || (!$this->block->level->getBlock($this->block) instanceof Wood && !$this->block->level->getBlock($this->block) instanceof Wood2) || $this->player->level->getId() != $this->block->level->getId()) {
                        $this->player->isBreaking = null;
                        $this->player->isWooding = false;
                        return;
                    }
                    if(!$this->player->isBreaking->equals($this->block))
                        return;
                    $it = $this->player->getInventory()->getItem(0);
                    $this->player->isBreaking = null;
                    $this->player->isWooding = false;
                    $ev = new BlockBreakEvent($this->player->getOwner(), $this->block, $it);
                    $ev->call();
                    if(!$ev->isCancelled()) {
                        $this->player->break($this->block, $it);
                        $this->player->getInventory()->setItem(0, $it);
                        $center = $this->player->level->getBlock($this->block);
                        $down = $this->player->level->getBlock($this->block->add(0, -1));
                        if(($down->getId() == Block::DIRT || $down->getId() == Block::GRASS) && $center->getId() == Block::AIR) {
                            if($this->player->inventory->contains(Item::get(Item::SAPLING))) {
                                $this->player->inventory->removeItem(Item::get(Item::SAPLING));
                                $this->player->level->setBlock($center, Block::get(Block::SAPLING));
                                $this->player->pitch = 0;
                            }
                        }
                    }
                    $up = $this->block->level->getBlock($this->block->add(0, 1));
                    if(($up instanceof Wood || $up instanceof Wood2) && $up->distance($this->player) <= 4.5) {
                        $this->player->lookAt($up);
                        $this->block->level->broadcastLevelEvent($up, LevelEventPacket::EVENT_BLOCK_START_BREAK, (int)(3900/$up->getBreakTime($this->player->getInventory()->getItem(0))));
                        $this->player->isBreaking = $up;
                        Workers::$instance->getScheduler()->scheduleDelayedTask(new self($this->player, $up, $this->woods), $up->getBreakTime($this->player->getInventory()->getItem(0))*20);
                    } else {
                        array_shift($this->woods);
                        $this->player->woods = $this->woods;
                        $this->player->goAndWood();
                    }
                }
            }, $block->getBreakTime($this->getInventory()->getItem(0))*20);
        } else {
            $this->lookAt($wood);
            $direction = $this->getDirectionVector()->multiply(0.3);
            $this->move($direction->x, 0, $direction->z);
            $this->woods = $woods;
            $this->goAndWood();
        }
    }
    public function getTargetBlockCopy(float $yaw, float $pitch, float $eyeHeight): ?Block {
        $line = $this->getLineOfSightCopy($yaw, $pitch, $eyeHeight);
        if(count($line) > 0)
            return array_shift($line);
        return null;
    }
    public function getLineOfSightCopy(float $yaw, float $pitch, float $eyeHeight): array {
        $maxDistance = 50;
        $blocks = [];
        $nextIndex = 0;
        foreach(VoxelRayTrace::inDirection($this->add(0, $eyeHeight), $this->getDirectionVectorCopy($yaw, $pitch), $maxDistance) as $vector3){
            $block = $this->level->getBlockAt($vector3->x, $vector3->y, $vector3->z);
            $blocks[$nextIndex++] = $block;
            if(count($blocks) > 1){
                array_shift($blocks);
                --$nextIndex;
            }
            if($block instanceof Solid)
                break;
        }
        return $blocks;
    }
    public function lookAtCopyYaw(Vector3 $target): float {
        $xDist = $target->x - $this->x;
        $zDist = $target->z - $this->z;
        $yaw = atan2($zDist, $xDist) / M_PI * 180 - 90;
        if($yaw < 0)
            $yaw += 360.0;
        return $yaw;
    }
    public function lookAtCopyPitch(Vector3 $target): float {
        $horizontal = sqrt(($target->x - $this->x) ** 2 + ($target->z - $this->z) ** 2);
        $vertical = $target->y - $this->y;
        return -atan2($vertical, $horizontal) / M_PI * 180;
    }
    public function getDirectionVectorCopy(float $yaw, float $pitch): Vector3 {
        $y = -sin(deg2rad($pitch));
        $xz = cos(deg2rad($pitch));
        $x = -$xz * sin(deg2rad($yaw));
        $z = $xz * cos(deg2rad($yaw));
        return $this->temporalVector->setComponents($x, $y, $z)->normalize();
    }
    public function spawnTo(Player $player): void {
        parent::spawnTo($player);
        $this->inventory->saveInventory();
    }
    protected function sendSpawnPacket(Player $player): void {
        $pk = new AddActorPacket();
        $pk->entityRuntimeId = $this->getId();
        $pk->type = "minecraft:villager_v2";
        $pk->position = $this->asVector3();
        $pk->motion = $this->getMotion();
        $pk->yaw = $this->yaw;
        $pk->headYaw = $this->yaw;
        $pk->pitch = $this->pitch;
        $pk->attributes = $this->attributeMap->getAll();
        $pk->metadata = $this->propertyManager->getAll();
        $player->dataPacket($pk);
        $this->armorInventory->sendContents($player);
    }

    public function getMaxHealth(): int {
        return 100;
    }
    public function saveNBT(): void {
        $this->namedtag->setString("id", $this->getSaveId(), true);
        if($this->getNameTag() !== ""){
            $this->namedtag->setString("CustomName", $this->getNameTag());
            $this->namedtag->setByte("CustomNameVisible", $this->isNameTagVisible() ? 1 : 0);
        }else{
            $this->namedtag->removeTag("CustomName", "CustomNameVisible");
        }
        $this->namedtag->setTag(new ListTag("Pos", [
            new DoubleTag("", $this->x),
            new DoubleTag("", $this->y),
            new DoubleTag("", $this->z)
        ]));
        $this->namedtag->setTag(new ListTag("Motion", [
            new DoubleTag("", $this->motion->x),
            new DoubleTag("", $this->motion->y),
            new DoubleTag("", $this->motion->z)
        ]));
        $this->namedtag->setTag(new ListTag("Rotation", [
            new FloatTag("", $this->yaw),
            new FloatTag("", $this->pitch)
        ]));
        $this->namedtag->setFloat("FallDistance", $this->fallDistance);
        $this->namedtag->setShort("Fire", $this->fireTicks);
        $this->namedtag->setShort("Air", $this->propertyManager->getShort(self::DATA_AIR));
        $this->namedtag->setByte("OnGround", $this->onGround ? 1 : 0);
        $this->namedtag->setByte("Invulnerable", 0);
        if(count($this->effects) > 0){
            $effects = [];
            foreach($this->effects as $effect){
                $effects[] = new CompoundTag("", [
                    new ByteTag("Id", $effect->getId()),
                    new ByteTag("Amplifier", Binary::signByte($effect->getAmplifier())),
                    new IntTag("Duration", $effect->getDuration()),
                    new ByteTag("Ambient", $effect->isAmbient() ? 1 : 0),
                    new ByteTag("ShowParticles", $effect->isVisible() ? 1 : 0)
                ]);
            }

            $this->namedtag->setTag(new ListTag("ActiveEffects", $effects));
        }else{
            $this->namedtag->removeTag("ActiveEffects");
        }
    }
}