<?php

namespace OguzhanUmutlu\Workers\inventory;

use OguzhanUmutlu\Workers\entities\WorkerEntity;
use OguzhanUmutlu\Workers\lib\muqsit\invmenu\InvMenu;
use pocketmine\inventory\BaseInventory;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\nbt\tag\ListTag;
use pocketmine\network\mcpe\protocol\MobEquipmentPacket;
use pocketmine\network\mcpe\protocol\types\inventory\ItemStackWrapper;
use pocketmine\Server;

class WorkerInventory extends BaseInventory implements Inventory {
    /*** @var WorkerEntity */
    public $worker;
    /*** @var InvMenu[] */
    public $menus = [];
    public $lastTick = 0;
    public function __construct(WorkerEntity $worker, array $items = [], int $size = null, string $title = null) {
        parent::__construct($items, $size, $title);
        $this->worker = $worker;
    }

    public function getName(): string {
        return "WorkerInventory";
    }

    public function getDefaultSize(): int {
        return 27;
    }

    public function saveInventory(): void {
        if(!$this->worker instanceof WorkerEntity || $this->worker->isClosed()) return;
        $items = [];
        foreach($this->getContents() as $slot => $nbt) {
            $item = $nbt->nbtSerialize();
            $item->setInt("ItemSlot", $slot);
            $items[] = $item;
        }
        $this->worker->namedtag->setTag(new ListTag("WorkerInventory", $items));
        $this->worker->saveNBT();
        $pk = new MobEquipmentPacket();
        $pk->item = ItemStackWrapper::legacy($this->getItem(0));
        $pk->hotbarSlot = $pk->inventorySlot = 0;
        $pk->entityRuntimeId = $this->worker->getId();
        Server::getInstance()->broadcastPacket(Server::getInstance()->getOnlinePlayers(), $pk);
    }

    public function setContents(array $items, bool $send = true): void {
        parent::setContents($items, $send);
        foreach($this->menus as $menu)
            $menu->getInventory()->setContents($this->getContents());
        $this->saveInventory();
        $this->lastTick = Server::getInstance()->getTick();
    }

    public function setItem(int $index, Item $item, bool $send = true): bool {
        $res = parent::setItem($index, $item, $send);
        foreach($this->menus as $menu)
            $menu->getInventory()->setContents($this->getContents());
        $this->saveInventory();
        $this->lastTick = Server::getInstance()->getTick();
        if($index == 0 && $this->worker && !$this->worker->isClosed())
            $this->worker->refreshNameTag();
        return $res;
    }

    public function removeItem(Item ...$slots): array {
        $res = parent::removeItem(...$slots);
        foreach($this->menus as $menu)
            $menu->getInventory()->setContents($this->getContents());
        $this->saveInventory();
        $this->lastTick = Server::getInstance()->getTick();
        return $res;
    }

    public function remove(Item $item): void {
        foreach($this->menus as $menu)
            $menu->getInventory()->setContents($this->getContents());
        $this->saveInventory();
        $this->lastTick = Server::getInstance()->getTick();
    }
}