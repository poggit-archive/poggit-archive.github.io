<?php

namespace OguzhanUmutlu\Workers;

use OguzhanUmutlu\Workers\libs\dktapps\pmforms\CustomForm;
use OguzhanUmutlu\Workers\libs\dktapps\pmforms\CustomFormResponse;
use OguzhanUmutlu\Workers\libs\dktapps\pmforms\element\Toggle;
use OguzhanUmutlu\Workers\libs\dktapps\pmforms\MenuForm;
use OguzhanUmutlu\Workers\libs\dktapps\pmforms\MenuOption;
use Exception;
use OguzhanUmutlu\Workers\libs\muqsit\invmenu\inventory\InvMenuInventory;
use OguzhanUmutlu\Workers\libs\muqsit\invmenu\InvMenu;
use OguzhanUmutlu\Workers\entities\WorkerEntity;
use OguzhanUmutlu\Workers\libs\muqsit\invmenu\transaction\InvMenuTransaction;
use OguzhanUmutlu\Workers\tasks\FormInventoryTask;
use pocketmine\entity\Entity;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\item\Food;
use pocketmine\item\Item;
use pocketmine\level\particle\HeartParticle;
use pocketmine\network\mcpe\protocol\InventoryTransactionPacket;
use pocketmine\network\mcpe\protocol\types\inventory\UseItemOnEntityTransactionData;
use pocketmine\Player;
use pocketmine\scheduler\Task;

class EventListener implements Listener {
    public function onUseSpawnEgg(PlayerInteractEvent $event) {
        Workers::$instance->getScheduler()->scheduleDelayedTask(new class($event) extends Task {
            public $event;
            public function __construct(PlayerInteractEvent $event) {
                $this->event = $event;
            }
            public function onRun(int $currentTick) {
                $event = $this->event;
                if($event->isCancelled()) return;
                $player = $event->getPlayer();
                $item = $event->getItem();
                if($event->getAction() != PlayerInteractEvent::RIGHT_CLICK_BLOCK) return;
                $typeConvert = [
                    285 => WorkerEntity::TYPE_MINER,
                    286 => WorkerEntity::TYPE_ITEM_GRABBER,
                    287 => WorkerEntity::TYPE_LUMBERJACK
                ];
                if($item->getId() == Item::SPAWN_EGG && in_array($item->getDamage(), array_keys($typeConvert)) && $player->getInventory()->contains(Item::get(Item::SPAWN_EGG, $item->getDamage()))) {
                    $face = $event->getBlock();
                    switch($event->getFace()) {
                        case 1:
                            $face = $face->add(0, 1);
                            break;
                        case 2:
                            $face = $face->add(0, 0, -1);
                            break;
                        case 3:
                            $face = $face->add(0, 0, 1);
                            break;
                        case 4:
                            $face = $face->add(-1);
                            break;
                        case 5:
                            $face = $face->add(1);
                            break;
                        default:
                            $face = $face->add(0, -1);
                    }
                    $face = $face->add(0.5, 0, 0.5);
                    if(!$event->getBlock()->level->isChunkLoaded($face->x >> 4, $face->z >> 4))
                        $event->getBlock()->level->loadChunk($face->x >> 4, $face->z >> 4);
                    $nbt = Entity::createBaseNBT($face);
                    $nbt->setInt("workerType", $typeConvert[$item->getDamage()]);
                    $nbt->setString("workerOwner", $event->getPlayer()->getName());
                    if($item->getNamedTag()->hasTag("WorkerInventory"))
                        $nbt->setTag($item->getNamedTag()->getListTag("WorkerInventory"));
                    if($item->getNamedTag()->hasTag("workerFood"))
                        $nbt->setFloat("workerFood", $item->getNamedTag()->getFloat("workerFood"));
                    if($item->getNamedTag()->hasTag("disallowedItems"))
                        $nbt->setIntArray("disallowedItems", $item->getNamedTag()->getIntArray("disallowedItems"));
                    $entity = Entity::createEntity("WorkerEntity", $event->getBlock()->level, $nbt);
                    if($item->getNamedTag()->hasTag("Health"))
                        $entity->setHealth($item->getNamedTag()->getFloat("Health"));
                    else $entity->setHealth($entity->getMaxHealth());
                    $entity->spawnToAll();
                    $event->setCancelled();
                    if(!$player->isCreative())
                        $player->getInventory()->removeItem(Item::get(Item::SPAWN_EGG, $item->getDamage()));
                }
            }
        }, 1);
    }
    public function onMove(PlayerMoveEvent $event) {
        $player = $event->getPlayer();
        if(!$player->boundingBox) return;
        $entities = $player->level->getCollidingEntities($player->boundingBox);
        foreach($entities as $entity) {
            if($entity instanceof WorkerEntity) {
                $yaw = atan2($player->z - $entity->z, $player->x - $entity->x) / M_PI * 180 - 90;
                if($yaw < 0)
                    $yaw += 360.0;
                $y = -sin(deg2rad(0));
                $xz = cos(deg2rad(0));
                $x = -$xz * sin(deg2rad($yaw));
                $z = $xz * cos(deg2rad($yaw));
                $direction = $entity->temporalVector->setComponents($x, $y, $z)->normalize();
                $entity->setMotion($direction->multiply(-0.5));
            }
        }
    }
    /**
     * @throws Exception
     */
    public function onRightClickEntity(DataPacketReceiveEvent $event) {
        $pk = $event->getPacket();
        $player = $event->getPlayer();
        if($pk instanceof InventoryTransactionPacket) {
            $trData = $pk->trData;
            if($trData instanceof UseItemOnEntityTransactionData && $trData->getActionType() != UseItemOnEntityTransactionData::ACTION_ATTACK) {
                $entity = $player->level->getEntity($trData->getEntityRuntimeId());
                if($entity instanceof WorkerEntity) {
                    $food = $player->getInventory()->getItemInHand();
                    if($food instanceof Food) {
                        if($entity->getFood() <= $entity->getMaxFood()-$food->getFoodRestore()) {
                            $entity->setFood($entity->getFood()+$food->getFoodRestore());
                            if($entity->getAge() < 7)
                                $entity->setAge($entity->getAge()+0.5);
                            $it = clone $food;
                            $it->count = 1;
                            if(!$player->isCreative())
                                $player->getInventory()->removeItem($it);
                            for($i=0;$i<3;$i++)
                                $entity->level->addParticle(new HeartParticle($entity->add(random_int(-10, 10)/10, random_int(0, 10)/10, random_int(-10, 10)/10)));
                        } else $entity->sendMessage("§dI'm not that hungry!");
                    } else if($food->getId() == 0) {
                        if($player->getName() != $entity->namedtag->getString("workerOwner")) {
                            $player->sendMessage("§c> You cannot manage others' workers!");
                            return;
                        }
                        $player->sendForm(
                            new MenuForm(
                                "Worker Menu",
                                "Select an action:",
                                array_merge([
                                    new MenuOption("Teleport worker to me"),
                                    new MenuOption("Teleport me to worker"),
                                    new MenuOption("Open worker's inventory"),
                                    new MenuOption("Convert to item")
                                ], $entity->type == WorkerEntity::TYPE_ITEM_GRABBER ? [new MenuOption("Manage collectable items")] : []),
                                function(Player $player, int $response) use ($entity): void {
                                    if($player->isClosed() || $entity->isClosed() || !$player->level || !$entity->level || $player->level->getId() != $entity->level->getId()) return;
                                    switch($response) {
                                        case 0:
                                            $entity->teleport($player, $entity->yaw, $entity->pitch);
                                            break;
                                        case 1:
                                            $player->teleport($entity);
                                            break;
                                        case 2:
                                            $id = count($entity->inventory->menus);
                                            $menu = InvMenu::create(InvMenu::TYPE_CHEST);
                                            $menu->setListener(function (InvMenuTransaction $transaction) use ($menu, $entity) {
                                                    Workers::$instance->getScheduler()->scheduleDelayedTask(new FormInventoryTask($menu, $entity), 1);
                                                    return $transaction->continue();
                                                })
                                                ->setInventoryCloseListener(function (Player $player, InvMenuInventory $inventory) use ($id, $entity) {
                                                    unset($entity->inventory->menus[$id]);
                                                });
                                            $entity->getInventory()->menus[] = $menu;
                                            $menu->getInventory()->setContents($entity->inventory->getContents());
                                            $menu->setName("Worker's inventory");
                                            $menu->send($player);
                                            break;
                                        case 3:
                                            $list = [
                                                WorkerEntity::TYPE_MINER => 285,
                                                WorkerEntity::TYPE_ITEM_GRABBER => 286,
                                                WorkerEntity::TYPE_LUMBERJACK => 287
                                            ];
                                            $item = Item::get(Item::SPAWN_EGG, $list[$entity->type]);
                                            $item->getNamedTag()->setTag($entity->namedtag->getListTag("WorkerInventory"));
                                            $item->getNamedTag()->setFloat("workerFood", $entity->getFood());
                                            $item->getNamedTag()->setFloat("Health", $entity->getHealth());
                                            $item->getNamedTag()->setIntArray("disallowedItems", $entity->namedtag->getIntArray("disallowedItems"));
                                            $entity->flagForDespawn();
                                            $player->getInventory()->addItem($item);
                                            break;
                                        case 4:
                                            if($entity->type != WorkerEntity::TYPE_ITEM_GRABBER) {
                                                $player->sendMessage("§c> Wait that's illegal!");
                                                break;
                                            }
                                            $disallowed = $entity->namedtag->getIntArray("disallowedItems", []);
                                            $player->sendForm(
                                                new CustomForm(
                                                    "Worker Menu > Manage collectable items",
                                                    [
                                                        new Toggle("sapling", "Saplings", !in_array(Item::SAPLING, $disallowed)),
                                                        new Toggle("potato", "Potatoes", !in_array(Item::POTATO, $disallowed)),
                                                        new Toggle("wheat", "Wheat seeds", !in_array(Item::WHEAT_SEEDS, $disallowed)),
                                                        new Toggle("carrot", "Carrots", !in_array(Item::CARROT, $disallowed)),
                                                        new Toggle("beetroot", "Beetroot seeds", !in_array(Item::BEETROOT_SEEDS, $disallowed))
                                                    ],
                                                    function(Player $player, CustomFormResponse $response) use ($entity): void {
                                                        $list = [];
                                                        if(!$response->getBool("sapling"))
                                                            $list[] = Item::SAPLING;
                                                        if(!$response->getBool("potato"))
                                                            $list[] = Item::POTATO;
                                                        if(!$response->getBool("wheat"))
                                                            $list[] = Item::WHEAT_SEEDS;
                                                        if(!$response->getBool("carrot"))
                                                            $list[] = Item::CARROT;
                                                        if(!$response->getBool("beetroot"))
                                                            $list[] = Item::BEETROOT_SEEDS;
                                                        $entity->namedtag->setIntArray("disallowedItems", $list);
                                                        $player->sendMessage("§a> Collectable items saved.");
                                                    }
                                                )
                                            );
                                            break;
                                    }
                                }
                            )
                        );
                    }
                }
            }
        }
    }
}
