<?php

namespace OguzhanUmutlu\Workers\tasks;

use OguzhanUmutlu\Workers\entities\WorkerEntity;
use OguzhanUmutlu\Workers\libs\muqsit\invmenu\InvMenu;
use OguzhanUmutlu\Workers\Workers;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class FormInventoryTask extends Task {
    public $menu;
    public $entity;
    public function __construct(InvMenu $menu, WorkerEntity $entity) {
        $this->menu = $menu;
        $this->entity = $entity;
    }
    public function onRun(int $currentTick) {
        $menu = $this->menu;
        $entity = $this->entity;
        if($entity->inventory->lastTick == Server::getInstance()->getTick()) {
            Workers::$instance->getScheduler()->scheduleDelayedTask(new self($menu, $entity), 1);
        } else $entity->getInventory()->setContents($menu->getInventory()->getContents());
    }
}
