<?php

/*
 * This file is part of Hydrogen.
 * (c) thebigcrafter <hello@thebigcrafter.xyz>
 * This source file is subject to the Apache-2.0 license that is bundled
 * with this source code in the file LICENSE.
 */

declare(strict_types=1);

namespace thebigcrafter\Hydrogen\eventLoop\Driver;

use thebigcrafter\Hydrogen\eventLoop\Internal\AbstractDriver;
use thebigcrafter\Hydrogen\eventLoop\Internal\DriverCallback;
use thebigcrafter\Hydrogen\eventLoop\Internal\SignalCallback;
use thebigcrafter\Hydrogen\eventLoop\Internal\StreamCallback;
use thebigcrafter\Hydrogen\eventLoop\Internal\StreamReadableCallback;
use thebigcrafter\Hydrogen\eventLoop\Internal\StreamWritableCallback;
use thebigcrafter\Hydrogen\eventLoop\Internal\TimerCallback;
use function assert;
use function ceil;
use function extension_loaded;
use function is_resource;
use function max;
use function min;
use function uv_is_active;
use function uv_loop_new;
use function uv_now;
use function uv_poll_init_socket;
use function uv_poll_start;
use function uv_poll_stop;
use function uv_run;
use function uv_signal_init;
use function uv_signal_start;
use function uv_signal_stop;
use function uv_timer_init;
use function uv_timer_start;
use function uv_timer_stop;
use function uv_update_time;
use const PHP_INT_MAX;

final class UvDriver extends AbstractDriver
{
	public static function isSupported() : bool
	{
		return extension_loaded("uv");
	}

	/** @var resource|\UVLoop A uv_loop resource created with uv_loop_new() */
	private $handle;
	/** @var array<string, resource> */
	private array $events = [];
	/** @var array<int, array<array-key, DriverCallback>> */
	private array $callbacks = [];
	/** @var array<int, resource> */
	private array $streams = [];
	private readonly \Closure $ioCallback;
	private readonly \Closure $timerCallback;
	private readonly \Closure $signalCallback;

	public function __construct()
	{
		parent::__construct();

		$this->handle = uv_loop_new();

		$this->ioCallback = function ($event, $status, $events, $resource) : void {
			$callbacks = $this->callbacks[(int) $event];

			// Invoke the callback on errors, as this matches behavior with other loop back-ends.
			// Re-enable callback as libuv disables the callback on non-zero status.
			if ($status !== 0) {
				$flags = 0;
				foreach ($callbacks as $callback) {
					assert($callback instanceof StreamCallback);

					$flags |= $callback->invokable ? $this->getStreamCallbackFlags($callback) : 0;
				}
				uv_poll_start($event, $flags, $this->ioCallback);
			}

			foreach ($callbacks as $callback) {
				assert($callback instanceof StreamCallback);

				// $events is ORed with 4 to trigger callback if no events are indicated (0) or on UV_DISCONNECT (4).
				// http://docs.libuv.org/en/v1.x/poll.html
				if (!($this->getStreamCallbackFlags($callback) & $events || ($events | 4) === 4)) {
					continue;
				}

				$this->enqueueCallback($callback);
			}
		};

		$this->timerCallback = function ($event) : void {
			$callback = $this->callbacks[(int) $event][0];

			assert($callback instanceof TimerCallback);

			$this->enqueueCallback($callback);
		};

		$this->signalCallback = function ($event) : void {
			$callback = $this->callbacks[(int) $event][0];

			$this->enqueueCallback($callback);
		};
	}

	/**
	 * {@inheritdoc}
	 */
	public function cancel(string $callbackId) : void
	{
		parent::cancel($callbackId);

		if (!isset($this->events[$callbackId])) {
			return;
		}

		$event = $this->events[$callbackId];
		$eventId = (int) $event;

		if (isset($this->callbacks[$eventId][0])) { // All except IO callbacks.
			unset($this->callbacks[$eventId]);
		} elseif (isset($this->callbacks[$eventId][$callbackId])) {
			$callback = $this->callbacks[$eventId][$callbackId];
			unset($this->callbacks[$eventId][$callbackId]);

			assert($callback instanceof StreamCallback);

			if (empty($this->callbacks[$eventId])) {
				unset($this->callbacks[$eventId], $this->streams[(int) $callback->stream]);
			}
		}

		unset($this->events[$callbackId]);
	}

	/**
	 * @return \UVLoop|resource
	 */
	public function getHandle() : mixed
	{
		return $this->handle;
	}

	protected function now() : float
	{
		uv_update_time($this->handle);

		/** @psalm-suppress TooManyArguments */
		return uv_now($this->handle) / 1000;
	}

	/**
	 * {@inheritdoc}
	 */
	protected function dispatch(bool $blocking) : void
	{
		/** @psalm-suppress TooManyArguments */
		uv_run($this->handle, $blocking ? \UV::RUN_ONCE : \UV::RUN_NOWAIT);
	}

	/**
	 * {@inheritdoc}
	 */
	protected function activate(array $callbacks) : void
	{
		$now = $this->now();

		foreach ($callbacks as $callback) {
			$id = $callback->id;

			if ($callback instanceof StreamCallback) {
				assert(is_resource($callback->stream));

				$streamId = (int) $callback->stream;

				if (isset($this->streams[$streamId])) {
					$event = $this->streams[$streamId];
				} elseif (isset($this->events[$id])) {
					$event = $this->streams[$streamId] = $this->events[$id];
				} else {
					/** @psalm-suppress TooManyArguments */
					$event = $this->streams[$streamId] = uv_poll_init_socket($this->handle, $callback->stream);
				}

				$eventId = (int) $event;
				$this->events[$id] = $event;
				$this->callbacks[$eventId][$id] = $callback;

				$flags = 0;
				foreach ($this->callbacks[$eventId] as $w) {
					assert($w instanceof StreamCallback);

					$flags |= $w->enabled ? ($this->getStreamCallbackFlags($w)) : 0;
				}
				uv_poll_start($event, $flags, $this->ioCallback);
			} elseif ($callback instanceof TimerCallback) {
				if (isset($this->events[$id])) {
					$event = $this->events[$id];
				} else {
					$event = $this->events[$id] = uv_timer_init($this->handle);
				}

				$this->callbacks[(int) $event] = [$callback];

				uv_timer_start(
					$event,
					(int) min(max(0, ceil(($callback->expiration - $now) * 1000)), PHP_INT_MAX),
					$callback->repeat ? (int) min(max(0, ceil($callback->interval * 1000)), PHP_INT_MAX) : 0,
					$this->timerCallback
				);
			} elseif ($callback instanceof SignalCallback) {
				if (isset($this->events[$id])) {
					$event = $this->events[$id];
				} else {
					/** @psalm-suppress TooManyArguments */
					$event = $this->events[$id] = uv_signal_init($this->handle);
				}

				$this->callbacks[(int) $event] = [$callback];

				/** @psalm-suppress TooManyArguments */
				uv_signal_start($event, $this->signalCallback, $callback->signal);
			} else {
				// @codeCoverageIgnoreStart
				throw new \Error("Unknown callback type");
				// @codeCoverageIgnoreEnd
			}
		}
	}

	/**
	 * {@inheritdoc}
	 */
	protected function deactivate(DriverCallback $callback) : void
	{
		$id = $callback->id;

		if (!isset($this->events[$id])) {
			return;
		}

		$event = $this->events[$id];

		if (!uv_is_active($event)) {
			return;
		}

		if ($callback instanceof StreamCallback) {
			$flags = 0;
			foreach ($this->callbacks[(int) $event] as $w) {
				assert($w instanceof StreamCallback);

				$flags |= $w->invokable ? ($this->getStreamCallbackFlags($w)) : 0;
			}

			if ($flags) {
				uv_poll_start($event, $flags, $this->ioCallback);
			} else {
				uv_poll_stop($event);
			}
		} elseif ($callback instanceof TimerCallback) {
			uv_timer_stop($event);
		} elseif ($callback instanceof SignalCallback) {
			uv_signal_stop($event);
		} else {
			// @codeCoverageIgnoreStart
			throw new \Error("Unknown callback type");
			// @codeCoverageIgnoreEnd
		}
	}

	private function getStreamCallbackFlags(StreamCallback $callback) : int
	{
		if ($callback instanceof StreamWritableCallback) {
			return \UV::WRITABLE;
		}

		if ($callback instanceof StreamReadableCallback) {
			return \UV::READABLE;
		}

		throw new \Error('Invalid callback type');
	}
}
