<?php

namespace xenialdan\customui\event;

use pocketmine\event\plugin\PluginEvent;
use pocketmine\network\mcpe\protocol\DataPacket;
use pocketmine\network\mcpe\protocol\ModalFormResponsePacket;
use pocketmine\player\Player;
use pocketmine\plugin\Plugin;

abstract class UIEvent extends PluginEvent
{

    public static $handlerList;

    /** @var DataPacket|ModalFormResponsePacket $packet */
    protected $packet;
    /** @var Player */
    protected $player;

    public function __construct(Plugin $plugin, DataPacket $packet, Player $player)
    {
        $this->packet = $packet;
        $this->player = $player;
        parent::__construct($plugin);
    }

    public function getPacket(): DataPacket
    {
        return $this->packet;
    }

    public function getPlayer(): Player
    {
        return $this->player;
    }

    public function getID(): int
    {
        return $this->packet->formId;
    }

}